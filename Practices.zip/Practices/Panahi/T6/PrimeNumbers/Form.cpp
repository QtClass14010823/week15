#include "Form.h"

#include <QDebug>
#include <QtConcurrent>
#include <QMessageBox>

QFuture<int> Form::future;
QFutureWatcher<int> Form::futureWatcher;

Form::Form(QWidget *parent) : QWidget(parent)
{
    layout = new QGridLayout(this);
    lblMin = new QLabel("Minimum:", this);
    lblMax = new QLabel("Maximum:", this);
    editMin = new QLineEdit("1", this);
    editMax = new QLineEdit("1000", this);
    btnStart = new QPushButton("Start");

    layout->addWidget(lblMin, 0, 0);
    layout->addWidget(editMin, 0, 1);
    layout->addWidget(lblMax, 1, 0);
    layout->addWidget(editMax, 1, 1);
    layout->addWidget(btnStart, 2, 1);

    connect(btnStart, &QPushButton::clicked, this, &Form::onBtnStartClicked);
    connect(&futureWatcher, &QFutureWatcher<QStringList>::finished, this, &Form::onTaskFinished);
}

Form::~Form()
{
}

void Form::onBtnStartClicked()
{
    QList<int> numbers = createListOfNumbers(editMin->text().toInt(), editMax->text().toInt());

    future = QtConcurrent::mappedReduced(numbers, &Form::checkPrimeNumber, &Form::reduce);
    futureWatcher.setFuture(future);
}

void Form::onTaskFinished()
{
    QMessageBox::information(this, "information", QString("Task is finished.\nResult is %0.").arg(futureWatcher.result()));
}

QList<int> Form::createListOfNumbers(int min, int max)
{
    QList<int> list;

    for(int i = min; i <= max; i++)
        list.push_back(i);

    return list;
}

bool Form::checkPrimeNumber(int n)
{
    bool isPrime = (n >= 2);

    for(int j = 2; j <= n / 2; j++)
    {
        if(n % j == 0)
        {
            isPrime = false;
            break;
        }
    }

    if (isPrime)
        qDebug() << n;

    return isPrime;
}

void Form::reduce(int &result, const bool &n)
{
    if (n)
        result++;
}
