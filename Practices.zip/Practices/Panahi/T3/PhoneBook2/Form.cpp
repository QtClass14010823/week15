#include "Form.h"

#include "Global.h"

#include <QFile>
#include <QCoreApplication>
#include <QMessageBox>

Form::Form(QWidget *parent/* = Q_NULLPTR*/, Qt::WindowFlags f/* = Qt::WindowFlags()*/) :
    QWidget(parent, f)
{
    vLayout = new QVBoxLayout(this);

    // Contact Info
    grpBoxInfo = new QGroupBox("Info", this);
    contactInfoLayout = new QHBoxLayout(this);
    lblContactCountTitle = new QLabel("Contact Count:", this);
    lblContactCountValue = new QLabel(this);

    lblContactCountTitle->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Minimum);
    contactInfoLayout->addWidget(lblContactCountTitle);
    contactInfoLayout->addWidget(lblContactCountValue);
    grpBoxInfo->setLayout(contactInfoLayout);

    // Add Contact
    grpBoxAdd = new QGroupBox("Add", this);
    addLayout = new QGridLayout(this);
    lblAddName = new QLabel("Name:", this);
    lblAddTel = new QLabel("Telephone:", this);
    editAddName = new QLineEdit(this);
    editAddTel = new QLineEdit(this);
    btnAdd = new QPushButton("Add", this);

    editAddName->setMaxLength(sizeof(ContactInfo::name) - 1);
    addLayout->addWidget(lblAddName, 0, 0);
    addLayout->addWidget(editAddName, 0, 1);
    addLayout->addWidget(lblAddTel, 1, 0);
    addLayout->addWidget(editAddTel, 1, 1);
    addLayout->addWidget(btnAdd, 2, 1);
    grpBoxAdd->setLayout(addLayout);

    // Find Contact
    grpBoxFind = new QGroupBox("Find", this);
    findLayout = new QHBoxLayout(this);
    lblFindName = new QLabel("Name:", this);
    editFindName = new QLineEdit(this);
    btnFind = new QPushButton("Find", this);

    editFindName->setMaxLength(sizeof(ContactInfo::name) - 1);
    findLayout->addWidget(lblFindName);
    findLayout->addWidget(editFindName);
    findLayout->addWidget(btnFind);
    grpBoxFind->setLayout(findLayout);

    vLayout->addWidget(grpBoxInfo);
    vLayout->addWidget(grpBoxAdd);
    vLayout->addWidget(grpBoxFind);

    this->setLayout(vLayout);

    connect(btnAdd, &QPushButton::clicked, this, &Form::on_btnAdd_Clicked);
    connect(btnFind, &QPushButton::clicked, this, &Form::on_btnFind_Clicked);

    loadContactsFile();
    lblContactCountValue->setText(QString::number(contacts.count()));
}

Form::~Form()
{
    saveContactsToFile();
}

void Form::on_btnAdd_Clicked()
{
    bool ok = false;
    int tel = editAddTel->text().toInt(&ok);

    if (
            editAddName->text().trimmed().isEmpty() ||
            editAddTel->text().trimmed().isEmpty() ||
            !ok
            )
    {
        QMessageBox::critical(this, "Error", "The values are invalid.");
        return;
    }

    ContactInfo contact(editAddName->text().trimmed().toStdString().c_str(), tel);

    contacts.push_back(contact);
    lblContactCountValue->setText(QString::number(contacts.count()));

    QMessageBox::information(this, "Info", "Contact added successfully.");
}

void Form::on_btnFind_Clicked()
{
    foreach (ContactInfo contact,  contacts)
    {
        if (strcmp(editFindName->text().trimmed().toStdString().c_str(), contact.name) == 0)
        {
            QMessageBox::information(this, "Info", QString("The phone number is %0.").arg(contact.tel));
            return;
        }
    }

    QMessageBox::warning(this, "Warning", "Contact not found.");
}

void Form::loadContactsFile()
{
    contacts.clear();

    QString fullPath = QString("%0/%1").arg(qApp->applicationDirPath()).arg(FILE_NAME);
    QFile file(fullPath);
    ContactInfo contact;

    if (!file.open(QIODevice::ReadOnly))
        return;

    while (!file.atEnd())
    {
        if (file.read((char *)&contact, sizeof(contact)) == sizeof(contact))
        {
            contacts.push_back(contact);
        }
    }

    file.close();
}

void Form::saveContactsToFile()
{
    QString fullPath = QString("%0/%1").arg(qApp->applicationDirPath()).arg(FILE_NAME);
    QFile file(fullPath);

    if (!file.open(QIODevice::WriteOnly))
        return;

    foreach (ContactInfo contact,  contacts)
    {
        file.write((char *)&contact, sizeof(contact));
    }

    file.close();
}
