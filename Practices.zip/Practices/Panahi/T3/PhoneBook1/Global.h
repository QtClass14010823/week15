#ifndef GLOBAL_H
#define GLOBAL_H

#define FILE_NAME   "Data.dat"

#endif // GLOBAL_H
