#include "Form.h"

#include "Global.h"

#include <QFile>
#include <QCoreApplication>
#include <QMessageBox>

Form::Form(QWidget *parent/* = Q_NULLPTR*/, Qt::WindowFlags f/* = Qt::WindowFlags()*/) :
    QWidget(parent, f)
{
    vLayout = new QVBoxLayout(this);

    // Contact Info
    grpBoxInfo = new QGroupBox("Info", this);
    contactInfoLayout = new QHBoxLayout(this);
    lblContactCountTitle = new QLabel("Contact Count:", this);
    lblContactCountValue = new QLabel(this);

    lblContactCountTitle->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Minimum);
    contactInfoLayout->addWidget(lblContactCountTitle);
    contactInfoLayout->addWidget(lblContactCountValue);
    grpBoxInfo->setLayout(contactInfoLayout);

    // Add Contact
    grpBoxAdd = new QGroupBox("Add", this);
    addLayout = new QGridLayout(this);
    lblAddName = new QLabel("Name:", this);
    lblAddTel = new QLabel("Telephone:", this);
    editAddName = new QLineEdit(this);
    editAddTel = new QLineEdit(this);
    btnAdd = new QPushButton("Add", this);

    editAddName->setMaxLength(sizeof(ContactInfo::name) - 1);
    addLayout->addWidget(lblAddName, 0, 0);
    addLayout->addWidget(editAddName, 0, 1);
    addLayout->addWidget(lblAddTel, 1, 0);
    addLayout->addWidget(editAddTel, 1, 1);
    addLayout->addWidget(btnAdd, 2, 1);
    grpBoxAdd->setLayout(addLayout);

    // Find Contact
    grpBoxFind = new QGroupBox("Find", this);
    findLayout = new QHBoxLayout(this);
    lblFindName = new QLabel("Name:", this);
    editFindName = new QLineEdit(this);
    btnFind = new QPushButton("Find", this);

    editFindName->setMaxLength(sizeof(ContactInfo::name) - 1);
    findLayout->addWidget(lblFindName);
    findLayout->addWidget(editFindName);
    findLayout->addWidget(btnFind);
    grpBoxFind->setLayout(findLayout);

    vLayout->addWidget(grpBoxInfo);
    vLayout->addWidget(grpBoxAdd);
    vLayout->addWidget(grpBoxFind);

    this->setLayout(vLayout);

    connect(btnAdd, &QPushButton::clicked, this, &Form::on_btnAdd_Clicked);
    connect(btnFind, &QPushButton::clicked, this, &Form::on_btnFind_Clicked);

    lblContactCountValue->setText(QString::number(getContactCount()));
}

void Form::on_btnAdd_Clicked()
{
    bool ok = false;
    int tel = editAddTel->text().toInt(&ok);

    if (
            editAddName->text().trimmed().isEmpty() ||
            editAddTel->text().trimmed().isEmpty() ||
            !ok
            )
    {
        QMessageBox::critical(this, "Error", "The values are invalid.");
        return;
    }

    ContactInfo contact(editAddName->text().trimmed().toStdString().c_str(), tel);

    if (appendContactToFile(contact))
    {
        lblContactCountValue->setText(QString::number(getContactCount()));
        QMessageBox::information(this, "Info", "The contact has been successfully added to the file.");
    }
    else
    {
        QMessageBox::critical(this, "Error", "Error in appending contact!");
    }

}

void Form::on_btnFind_Clicked()
{
    int tel = 0;

    if (findContact(editFindName->text().trimmed(), &tel))
        QMessageBox::information(this, "Info", QString("The phone number is %0.").arg(tel));
    else
        QMessageBox::warning(this, "Warning", "Contact not found.");
}

int Form::getContactCount()
{
    QString fullPath = QString("%0/%1").arg(qApp->applicationDirPath()).arg(FILE_NAME);
    QFile file(fullPath);

    return file.size() / sizeof(ContactInfo);
}

bool Form::appendContactToFile(Form::ContactInfo contact)
{
    QString fullPath = QString("%0/%1").arg(qApp->applicationDirPath()).arg(FILE_NAME);
    QFile file(fullPath);

    if (!file.open(QIODevice::WriteOnly | QIODevice::Append))
        return false;

    if (!file.seek(file.size()))
    {
        file.close();
        return false;
    }

    if (!file.write((char *)&contact, sizeof(contact)))
    {
        file.close();
        return false;
    }

    file.close();

    return true;
}

bool Form::findContact(const QString name, int *tel)
{
    QString fullPath = QString("%0/%1").arg(qApp->applicationDirPath()).arg(FILE_NAME);
    QFile file(fullPath);
    ContactInfo contact;
    bool found = false;

    *tel = 0;

    if (!file.open(QIODevice::ReadOnly))
        return false;

    while (!file.atEnd())
    {
        if (file.read((char *)&contact, sizeof(contact)) == sizeof(contact))
        {
            if (strcmp(name.toStdString().c_str(), contact.name) == 0)
            {
                *tel = contact.tel;
                found = true;
                break;
            }
        }
    }

    file.close();

    return found;
}
