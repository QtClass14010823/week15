#include "Form.h"

Form::Form(QWidget *parent/* = Q_NULLPTR*/, Qt::WindowFlags f/* = Qt::WindowFlags()*/) :
    QWidget(parent, f)
{
    layout = new QGridLayout(this);
    lblText1 = new QLabel("Value 1:", this);
    lblText2 = new QLabel("Value 2:", this);
    editValue1 = new QLineEdit(this);
    editValue2 = new QLineEdit(this);
    btnSwap = new QPushButton("Swap Values", this);

    layout->addWidget(lblText1, 0, 0);
    layout->addWidget(editValue1, 0, 1);
    layout->addWidget(lblText2, 1, 0);
    layout->addWidget(editValue2, 1, 1);
    layout->addWidget(btnSwap, 2, 1);

    this->setLayout(layout);

    connect(btnSwap, &QPushButton::clicked, this, &Form::on_btnSwap_Clicked);
}

void Form::on_btnSwap_Clicked()
{
    QString text1 = editValue1->text();
    QString text2 = editValue2->text();

    swapValues(&text1, &text2);

    editValue1->setText(text1);
    editValue2->setText(text2);
}

void Form::swapValues(QString *s1, QString *s2)
{
    QString temp = *s1;

    *s1 = *s2;
    *s2 = temp;
}
