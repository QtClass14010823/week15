#include "CopyFile.h"

#include <QFile>

CopyFile::CopyFile(QObject *parent/* = nullptr*/)
    : QObject(parent)
{
    isSuspended = false;
    startCopyIsRunning = false;
}

void CopyFile::toggleExecutionState(bool isSuspended)
{
    if (!startCopyIsRunning || isSuspended == this->isSuspended)
        return;

    if (isSuspended)
        mutex.lock();
    else
        mutex.unlock();

    this->isSuspended = isSuspended;
}

void CopyFile::startCopy(QString srcFile, QString dstFile)
{
    QFile in(srcFile);
    QFile out(dstFile);
    char buff[10000];
    quint64 readLen = 0;
    quint64 totalReadLen = 0;
    int percentage = 0;

    in.open(QIODevice::ReadOnly);
    out.open(QIODevice::WriteOnly);

    startCopyIsRunning = true;
    emit progressChanged(0);

    while(!in.atEnd())
    {
        if (isSuspended)
        {
            mutex.lock();
            mutex.unlock();
        }

        readLen = in.read(buff, sizeof(buff));
        totalReadLen += readLen;

        if (readLen > 0)
        {
            out.write(buff, readLen);
            percentage = (float)totalReadLen / (float)in.size() * 100;

            emit progressChanged(percentage);
        }
    }

    out.close();
    in.close();
    startCopyIsRunning = false;
    emit copyFinished();
}
