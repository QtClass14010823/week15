#include "Form.h"

#include <QFile>
#include <QFileDialog>
#include <QMessageBox>

Form::Form(QWidget *parent) :
    QWidget(parent)
{
    gLayout = new QGridLayout(this);
    lblSrc = new QLabel("Source File:", this);
    lblDst = new QLabel("Destination File:", this);
    lnEditSrc = new QLineEdit(this);
    lnEditDst = new QLineEdit(this);
    btnSrcFile = new QPushButton("...", this);
    btnDstFile = new QPushButton("...", this);

    hLayout = new QHBoxLayout(this);
    btnCopy = new QPushButton("Copy", this);
    btnPause = new QPushButton("Pause", this);
    btnResume = new QPushButton("Resume", this);

    hLayout->addWidget(btnCopy);
    hLayout->addWidget(btnPause);
    hLayout->addWidget(btnResume);

    gLayout->addWidget(lblSrc, 0, 0);
    gLayout->addWidget(lblDst, 1, 0);
    gLayout->addWidget(lnEditSrc, 0, 1);
    gLayout->addWidget(lnEditDst, 1, 1);
    gLayout->addWidget(btnSrcFile, 0, 2);
    gLayout->addWidget(btnDstFile, 1, 2);
    gLayout->addLayout(hLayout, 2, 0, 1, 3);
    this->setLayout(gLayout);

    copyFileThread = new QThread(this);
    copyFile = new CopyFile;

    copyFile->moveToThread(copyFileThread);

    this->setWindowTitle("Copy File");
    connect(btnSrcFile, &QPushButton::clicked, this, &Form::onSrcClicked);
    connect(btnDstFile, &QPushButton::clicked, this, &Form::onDstClicked);
    connect(btnCopy, &QPushButton::clicked, this, &Form::onCopyClicked);
    connect(btnPause, &QPushButton::clicked, this, &Form::onPauseClicked);
    connect(btnResume, &QPushButton::clicked, this, &Form::onResumeClicked);
    connect(copyFile, &CopyFile::progressChanged, this, &Form::on_CopyFile_ProgressChanged);
    connect(copyFile, &CopyFile::copyFinished, this, &Form::on_CopyFile_Finished);
    connect(copyFileThread, &QThread::finished, copyFile, &QObject::deleteLater, Qt::AutoConnection);

    copyFileThread->start();
}

Form::~Form()
{
    if (copyFileThread->isRunning())
    {
        copyFileThread->quit();
        copyFileThread->wait();
    }
}

void Form::onSrcClicked()
{
    QString file1Name = QFileDialog::getOpenFileName(this,
             "Select source file", "/home", tr("All Files (*.*)"));

    lnEditSrc->setText(file1Name);
}

void Form::onDstClicked()
{
    QString file1Name = QFileDialog::getSaveFileName(this,
             "Select destination file", "/home", tr("All Files (*.*)"));

    lnEditDst->setText(file1Name);
}

void Form::onCopyClicked()
{
    QMetaObject::invokeMethod(copyFile, "startCopy", Qt::AutoConnection,
                              Q_ARG(QString, lnEditSrc->text()),
                              Q_ARG(QString, lnEditDst->text()));
}

void Form::onPauseClicked()
{
    copyFile->toggleExecutionState(true);
}

void Form::onResumeClicked()
{
    copyFile->toggleExecutionState(false);
}

void Form::on_CopyFile_ProgressChanged(int percent)
{
    this->setWindowTitle(QString("Copying %0%1").arg(percent).arg("%"));
}

void Form::on_CopyFile_Finished()
{
    this->setWindowTitle("Copy File");
    QMessageBox::information(this, "Information", "Copy completed.");
}
