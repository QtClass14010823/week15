#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>

class Form : public QWidget
{
	Q_OBJECT
	
public:
    Form(QWidget *parent = Q_NULLPTR, Qt::WindowFlags f = Qt::WindowFlags());
    void initForm(QStringList *args);

private slots:
    void on_btnClose_Clicked();

private:
};

#endif // FORM_H
