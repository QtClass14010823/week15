#ifndef WGTGETWEIGHT_H
#define WGTGETWEIGHT_H

#include <QWidget>
#include <QSpinBox>

class WgtGetWeight : public QWidget
{
    Q_OBJECT
public:
    explicit WgtGetWeight(QWidget *parent = nullptr);
    int getWeight();

signals:

private:
    QSpinBox *spnWeight;
};

#endif // WGTGETWEIGHT_H
