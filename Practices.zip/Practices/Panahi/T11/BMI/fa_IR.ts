<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fa_IR">
<context>
    <name>MainForm</name>
    <message>
        <location filename="MainForm.cpp" line="13"/>
        <source>Height (centimeter):</source>
        <translation>قد (سانتیمتر):</translation>
    </message>
    <message>
        <location filename="MainForm.cpp" line="15"/>
        <source>Weight (Kilograms):</source>
        <translation>وزن (کیلوگرم):</translation>
    </message>
    <message>
        <location filename="MainForm.cpp" line="17"/>
        <source>Result:</source>
        <translation>نتیجه:</translation>
    </message>
    <message>
        <location filename="MainForm.cpp" line="19"/>
        <source>Calculate BMI</source>
        <translation>محاسبه شاخص توده بدنی</translation>
    </message>
    <message>
        <location filename="MainForm.cpp" line="20"/>
        <source>Exit</source>
        <translation>خروج</translation>
    </message>
    <message>
        <location filename="MainForm.cpp" line="31"/>
        <source>BMI</source>
        <translation>شاخص توده بدنی</translation>
    </message>
</context>
<context>
    <name>WgtGetHeight</name>
    <message>
        <location filename="WgtGetHeight.cpp" line="9"/>
        <source>Height (centimeter):</source>
        <translation>قد (سانتیمتر):</translation>
    </message>
</context>
<context>
    <name>WgtGetWeight</name>
    <message>
        <location filename="WgtGetWeight.cpp" line="9"/>
        <source>Weight (Kilograms):</source>
        <translation>وزن (کیلوگرم):</translation>
    </message>
</context>
<context>
    <name>WgtIntroduction</name>
    <message>
        <location filename="WgtIntroduction.cpp" line="11"/>
        <source>Body mass index is a value derived from the mass and height of a person. The BMI is defined as the body mass divided by the square of the body height, and is expressed in units of kg/m², resulting from mass in kilograms and height in metres.</source>
        <translation>شاخص توده بدنی یا BMI یکی از معیارهای تشخیص توده چربی است که برای بزرگ‌سالان استفاده می‌شود. عوامل مختلفی می‌تواند در ارزیابی این معیار دخیل باشد. بسیاری از افراد با عدد BMI یکسان، بافت چربی یکسانی در بدن ندارند. برای ارزیابی دقیق وزن و توده چربی خود بهتر است این ارزیابی را تحت نظر پزشک انجام دهید.</translation>
    </message>
</context>
<context>
    <name>WgtWizard</name>
    <message>
        <location filename="WgtWizard.cpp" line="28"/>
        <source>&lt; Back</source>
        <translation>&lt; قبلی</translation>
    </message>
    <message>
        <location filename="WgtWizard.cpp" line="29"/>
        <source>Next &gt;</source>
        <translation>بعدی &gt;</translation>
    </message>
    <message>
        <location filename="WgtWizard.cpp" line="30"/>
        <source>Finish</source>
        <translation>اتمام</translation>
    </message>
    <message>
        <location filename="WgtWizard.cpp" line="44"/>
        <source>BMI Wizard</source>
        <translation>جادوگر شاخص توده بدنی</translation>
    </message>
</context>
</TS>
