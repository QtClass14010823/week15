#include <QApplication>
#include <QTranslator>

#include "MainForm.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QTranslator translator;

    translator.load("fa_IR.qm");
    app.installTranslator(&translator);
    app.setLayoutDirection(Qt::RightToLeft);

    MainForm frm;
    frm.show();

    return app.exec();
}
