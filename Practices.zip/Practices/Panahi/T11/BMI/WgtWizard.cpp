#include "WgtWizard.h"

#include <QHBoxLayout>
#include <QFrame>
#include <QSpacerItem>

#include "WgtIntroduction.h"
#include "WgtGetHeight.h"
#include "WgtGetWeight.h"

WgtWizard::WgtWizard(QWidget *parent) : QDialog(parent)
{
    QVBoxLayout *layVBoxMain = new QVBoxLayout;
    layoutContainer = new QHBoxLayout;
    QFrame *frmLine = new QFrame;

    frmLine->setFrameShape(QFrame::HLine);
    frmLine->setFrameShadow(QFrame::Sunken);

    QHBoxLayout *layHBoxCmd = new QHBoxLayout;

    layVBoxMain->addLayout(layoutContainer);
    layVBoxMain->addWidget(frmLine);
    layVBoxMain->addLayout(layHBoxCmd);

    QSpacerItem *horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
    btnBack = new QPushButton(tr("< Back"));
    btnNext = new QPushButton(tr("Next >"));
    btnFinish = new QPushButton(tr("Finish"));

    layHBoxCmd->addWidget(btnBack);
    layHBoxCmd->addItem(horizontalSpacer);
    layHBoxCmd->addWidget(btnNext);
    layHBoxCmd->addWidget(btnFinish);

    prevPage = -1;
    currentPage = 0;
    pages.push_back(new WgtIntroduction);
    pages.push_back(new WgtGetHeight);
    pages.push_back(new WgtGetWeight);
    updatePage();

    setLayout(layVBoxMain);
    resize(300, 200);
    setWindowTitle(tr("BMI Wizard"));

    connect(btnBack, &QPushButton::clicked, this, &WgtWizard::onBtnPrevClicked);
    connect(btnNext, &QPushButton::clicked, this, &WgtWizard::onBtnNextClicked);
    connect(btnFinish, &QPushButton::clicked, this, &WgtWizard::onBtnFinishClicked);
}

WgtWizard::~WgtWizard()
{
    if (currentPage > -1)
        pages[currentPage]->setParent(nullptr);

    foreach (QWidget *page, pages)
    {
        delete page;
    }
}

int WgtWizard::getHeight()
{
    return dynamic_cast<WgtGetHeight *>(pages[1])->getHeight();
}

int WgtWizard::getWeight()
{
    return dynamic_cast<WgtGetWeight *>(pages[2])->getWeight();
}

void WgtWizard::onBtnPrevClicked()
{
    if (currentPage == 0)
        return;

    currentPage--;
    updatePage();
}

void WgtWizard::onBtnNextClicked()
{
    if (currentPage == pages.count() - 1)
        return;

    currentPage++;
    updatePage();
}

void WgtWizard::onBtnFinishClicked()
{
    if (currentPage == pages.count() - 1)
        accept();
}

void WgtWizard::updatePage()
{
    if (prevPage > -1)
    {
        layoutContainer->removeWidget(pages[prevPage]);
        pages[prevPage]->hide();
    }

    layoutContainer->addWidget(pages[currentPage]);

    if (!this->isHidden())
        pages[currentPage]->show();

    if (currentPage == 0)
    {
        btnBack->setDisabled(true);

        if (pages.count() == 1)
        {
            btnNext->setDisabled(true);
            btnNext->hide();
            btnFinish->setEnabled(true);
            btnFinish->show();
        }
        else
        {
            btnNext->setEnabled(true);

            if (!this->isHidden())
                btnNext->show();

            btnFinish->setDisabled(true);
            btnFinish->hide();
        }
    }
    else if (currentPage == pages.count() - 1)
    {
        btnBack->setEnabled(true);
        btnNext->setDisabled(true);
        btnNext->hide();
        btnFinish->setEnabled(true);

        if (!this->isHidden())
            btnFinish->show();
    }
    else
    {
        btnBack->setEnabled(true);
        btnNext->setEnabled(true);

        if (!this->isHidden())
            btnNext->show();

        btnFinish->setDisabled(true);
        btnFinish->hide();
    }

    prevPage = currentPage;
}
