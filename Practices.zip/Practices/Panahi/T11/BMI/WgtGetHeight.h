#ifndef WGTGETHEIGHT_H
#define WGTGETHEIGHT_H

#include <QWidget>
#include <QSpinBox>

class WgtGetHeight : public QWidget
{
    Q_OBJECT
public:
    explicit WgtGetHeight(QWidget *parent = nullptr);
    int getHeight();

signals:

private:
    QSpinBox *spnHeight;
};

#endif // WGTGETHEIGHT_H
