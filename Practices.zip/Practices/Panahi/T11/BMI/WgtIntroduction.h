#ifndef WGTINTRODUCTION_H
#define WGTINTRODUCTION_H

#include <QWidget>

class WgtIntroduction : public QWidget
{
    Q_OBJECT
public:
    explicit WgtIntroduction(QWidget *parent = nullptr);

signals:

};

#endif // WGTINTRODUCTION_H
