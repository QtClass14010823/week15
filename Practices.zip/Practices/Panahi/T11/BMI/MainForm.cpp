#include "MainForm.h"

#include <QCoreApplication>
#include <QGridLayout>
#include <QPushButton>
#include <QLabel>
#include <QFrame>

#include "WgtWizard.h"

MainForm::MainForm(QWidget *parent) : QWidget(parent)
{
    QGridLayout *mainLayout = new QGridLayout;
    lblHeightText = new QLabel(tr("Height (centimeter):"));
    lblHeightValue = new QLabel("-");
    lblWeightText = new QLabel(tr("Weight (Kilograms):"));
    lblWeightValue = new QLabel("-");
    lblResultText = new QLabel(tr("Result:"));
    lblResultValue = new QLabel("-");

    QFrame *frmLine = new QFrame;

    frmLine->setFrameShape(QFrame::HLine);
    frmLine->setFrameShadow(QFrame::Sunken);

    btnCalcBMI = new QPushButton(tr("Calculate BMI"));
    QPushButton *btnExit = new QPushButton(tr("Exit"));

    mainLayout->addWidget(lblHeightText, 0, 0);
    mainLayout->addWidget(lblHeightValue, 0, 1);
    mainLayout->addWidget(lblWeightText, 1, 0);
    mainLayout->addWidget(lblWeightValue, 1, 1);
    mainLayout->addWidget(lblResultText, 2, 0);
    mainLayout->addWidget(lblResultValue, 2, 1);
    mainLayout->addWidget(frmLine, 3, 0, 1, 2);
    mainLayout->addWidget(btnCalcBMI, 4, 0);
    mainLayout->addWidget(btnExit, 4, 1);
    setLayout(mainLayout);
    setWindowTitle(tr("BMI"));
    resize(250, 100);

    connect(btnCalcBMI, &QPushButton::clicked, this, &MainForm::onBtnCalcBMIClicked);
    connect(btnExit, &QPushButton::clicked, qApp, &QCoreApplication::quit);
}

void MainForm::onBtnCalcBMIClicked()
{
    WgtWizard wzd(this);

    if (wzd.exec() == QDialog::Accepted)
    {
        float result = (float)wzd.getWeight() /
                (
                    ((float)wzd.getHeight() / 100) *
                    ((float)wzd.getHeight() / 100)
                );

        lblHeightValue->setText(QString::number(wzd.getHeight()));
        lblWeightValue->setText(QString::number(wzd.getWeight()));
        lblResultValue->setText(QString::number(result));
    }
    else
    {
        lblHeightValue->setText("-");
        lblWeightValue->setText("-");
        lblResultValue->setText("-");
    }
}
