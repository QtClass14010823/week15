#include "WgtIntroduction.h"

#include <QLabel>
#include <QVBoxLayout>

WgtIntroduction::WgtIntroduction(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *layVBoxMain = new QVBoxLayout;
    QLabel *lblText = new QLabel;

    layVBoxMain->setSpacing(0);
    layVBoxMain->setMargin(0);
    lblText->setText(tr("Body mass index is a value derived from the mass and height of a person. "
                        "The BMI is defined as the body mass divided by the square of the body height, "
                        "and is expressed in units of kg/m², resulting from mass in kilograms and height in metres."
                    ));
    lblText->setWordWrap(true);
    lblText->setFrameShape(QFrame::Panel);
    lblText->setFrameShadow(QFrame::Sunken);
    lblText->setAlignment(Qt::AlignJustify);
    lblText->setMargin(5);

    layVBoxMain->addWidget(lblText);

    setLayout(layVBoxMain);
}
