#ifndef WGTWIZARD_H
#define WGTWIZARD_H

#include <QDialog>
#include <QPushButton>
#include <QList>
#include <QHBoxLayout>

class WgtWizard : public QDialog
{
    Q_OBJECT
public:
    explicit WgtWizard(QWidget *parent = nullptr);
    ~WgtWizard();
    int getHeight();
    int getWeight();

signals:

private slots:
    void onBtnPrevClicked();
    void onBtnNextClicked();
    void onBtnFinishClicked();

private:
    QHBoxLayout *layoutContainer;
    QList<QWidget *> pages;
    QPushButton *btnBack;
    QPushButton *btnNext;
    QPushButton *btnFinish;
    int currentPage, prevPage;

    void updatePage();
};

#endif // WGTWIZARD_H
