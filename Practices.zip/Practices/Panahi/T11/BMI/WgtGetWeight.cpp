#include "WgtGetWeight.h"

#include <QLabel>
#include <QHBoxLayout>

WgtGetWeight::WgtGetWeight(QWidget *parent) : QWidget(parent)
{
    QHBoxLayout *layHBoxMain = new QHBoxLayout;
    QLabel *lblText = new QLabel(tr("Weight (Kilograms):"));;
    spnWeight = new QSpinBox;

    layHBoxMain->setSpacing(0);
    layHBoxMain->setMargin(0);
    spnWeight->setMinimum(30);
    spnWeight->setMaximum(150);
    spnWeight->setValue(70);

    layHBoxMain->addWidget(lblText);
    layHBoxMain->addWidget(spnWeight);
    setLayout(layHBoxMain);
}

int WgtGetWeight::getWeight()
{
    return spnWeight->value();
}
