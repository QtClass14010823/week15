#ifndef MAINFORM_H
#define MAINFORM_H

#include <QWidget>

class QPushButton;
class QLabel;

class MainForm : public QWidget
{
    Q_OBJECT
public:
    explicit MainForm(QWidget *parent = nullptr);

signals:

private slots:
    void onBtnCalcBMIClicked();

private:
    QLabel *lblHeightText;
    QLabel *lblHeightValue;
    QLabel *lblWeightText;
    QLabel *lblWeightValue;
    QLabel *lblResultText;
    QLabel *lblResultValue;
    QPushButton *btnCalcBMI;
};

#endif // MAINFORM_H
