#include "WgtGetHeight.h"

#include <QLabel>
#include <QHBoxLayout>

WgtGetHeight::WgtGetHeight(QWidget *parent) : QWidget(parent)
{
    QHBoxLayout *layHBoxMain = new QHBoxLayout;
    QLabel *lblText = new QLabel(tr("Height (centimeter):"));;
    spnHeight = new QSpinBox;

    layHBoxMain->setSpacing(0);
    layHBoxMain->setMargin(0);
    spnHeight->setMinimum(50);
    spnHeight->setMaximum(250);
    spnHeight->setValue(180);

    layHBoxMain->addWidget(lblText);
    layHBoxMain->addWidget(spnHeight);
    setLayout(layHBoxMain);
}

int WgtGetHeight::getHeight()
{
    return spnHeight->value();
}
