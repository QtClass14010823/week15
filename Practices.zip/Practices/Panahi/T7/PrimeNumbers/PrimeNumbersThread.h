#ifndef PRIMENUMBERSTHREAD_H
#define PRIMENUMBERSTHREAD_H

#include <QThread>
#include <QObject>
#include <QSemaphore>

#include "Global.h"

class PrimeNumbersThread : public QThread
{
    Q_OBJECT

public:
    PrimeNumbersThread(QObject *parent = nullptr);
    void setParams(int instance, int min, int max);
    void toggleExecutionState(bool isSuspended);

protected:
    void run() Q_DECL_OVERRIDE;

signals:
    void resourceUpdated(int instance, bool isOccupied);

private:
    bool isPrime(int n);

    static QSemaphore semaphore;
    int buffer[BUFFER_SIZE];
    int instance;
    int min;
    int max;
};

#endif // PRIMENUMBERSTHREAD_H
