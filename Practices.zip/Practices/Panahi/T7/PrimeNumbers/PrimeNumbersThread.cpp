#include "PrimeNumbersThread.h"

#include <QFile>
#include <QTextStream>

QSemaphore PrimeNumbersThread::semaphore(MAX_FILE_NUMBER);

PrimeNumbersThread::PrimeNumbersThread(QObject *parent/* = nullptr*/)
    : QThread(parent)
{
}

void PrimeNumbersThread::setParams(int instance, int min, int max)
{
    this->instance = instance;
    this->min = min;
    this->max = max;
}

void PrimeNumbersThread::run()
{
    int index = 0;

    for (int n = min; n < max; n++)
    {
        if (isPrime(n))
        {
            buffer[index++] = n;
        }

        if (index == BUFFER_SIZE || n == max - 1)
        {
            semaphore.acquire();

            emit resourceUpdated(instance, true);

            QString fileName = QString("Data-%0%1.txt").
                    arg((instance + 1 < 10) ? "0" : "").
                    arg(instance + 1);

            QFile file(fileName);
            file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text);
            QTextStream out(&file);

            for(int c = 0; c < index; c++)
            {
                out << buffer[c] << "\n";
                QThread::msleep(1);
            }

            file.close();

            semaphore.release();

            index = 0;
            emit resourceUpdated(instance, false);
        }
    }
}

bool PrimeNumbersThread::isPrime(int n)
{
    bool isPrime = (n >= 2);

    for(int j = 2; j <= n / 2; j++)
    {
        if(n % j == 0)
        {
            isPrime = false;
            break;
        }
    }

    return isPrime;
}
