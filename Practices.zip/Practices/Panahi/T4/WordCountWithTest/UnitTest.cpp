#include "UnitTest.h"

#include <QFile>

#include "Global.h"
#include "Form.h"

UnitTest::UnitTest(QObject *parent) : QObject(parent)
{
}

void UnitTest::wordCount_data()
{
    QTest::addColumn<QString>("FilePath");
    QTest::addColumn<int>("WordCount");

    QString fullPath = QString("%0/%1").arg(qApp->applicationDirPath()).arg(FILE_NAME);
    QFile file(fullPath);

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    QTextStream textStream(&file);
    int index = 1;

    while (!textStream.atEnd()) {
        const QStringList path =  textStream.readLine().split(':');
        QTest::newRow(QString("Row Number %0").arg(index++).toStdString().c_str()) << QString("%0/%1").arg(qApp->applicationDirPath()).arg(path.at(0)) << path.at(1).toInt();
    }

    file.close();
}

void UnitTest::wordCount()
{
    QFETCH(QString, FilePath);
    QFETCH(int, WordCount);

    Form form;

    QCOMPARE(form.wordCount(FilePath), WordCount);
}
