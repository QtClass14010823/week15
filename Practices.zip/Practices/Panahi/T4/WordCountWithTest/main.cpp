#include <QApplication>

#include "UnitTest.h"
#include "Form.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

#ifndef TEST_MODE
    Form form;

    form.show();
#else
    UnitTest test;
    return QTest::qExec(&test, argc, argv);
#endif

#ifndef TEST_MODE
    return a.exec();
#endif
}
