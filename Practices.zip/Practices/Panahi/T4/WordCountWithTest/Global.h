#ifndef GLOBAL_H
#define GLOBAL_H

#define FILE_NAME   "TestData.txt"

#endif // GLOBAL_H
