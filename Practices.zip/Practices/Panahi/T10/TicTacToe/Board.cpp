#include "Board.h"

#include <QGridLayout>
#include <QPushButton>
#include <QVariant>
#include <QDebug>
#include <QThread>
#include <QMessageBox>

Board::Board(QWidget *parent) : QWidget(parent)
{
    turn = Logic::EMPTY;
    eventbasedThread = new QThread(this);

    logic.moveToThread(eventbasedThread);

    QGridLayout *layGriMain = new QGridLayout;

    layGriMain->setSpacing(0);

    for (int i = 0; i < 9; i++)
        pieces[i] = makePiece(i + 1);

    layGriMain->addWidget(makeLine(QFrame::HLine), 0, 0, 1, 7);
    layGriMain->addWidget(pieces[0], 1, 1);
    layGriMain->addWidget(pieces[1], 1, 3);
    layGriMain->addWidget(pieces[2], 1, 5);
    layGriMain->addWidget(makeLine(QFrame::HLine), 2, 0, 1, 7);
    layGriMain->addWidget(pieces[3], 3, 1);
    layGriMain->addWidget(pieces[4], 3, 3);
    layGriMain->addWidget(pieces[5], 3, 5);
    layGriMain->addWidget(makeLine(QFrame::HLine), 4, 0, 1, 7);
    layGriMain->addWidget(pieces[6], 5, 1);
    layGriMain->addWidget(pieces[7], 5, 3);
    layGriMain->addWidget(pieces[8], 5, 5);
    layGriMain->addWidget(makeLine(QFrame::HLine), 6, 0, 1, 7);
    layGriMain->addWidget(makeLine(QFrame::VLine), 0, 0, 7, 1);
    layGriMain->addWidget(makeLine(QFrame::VLine), 0, 2, 7, 1);
    layGriMain->addWidget(makeLine(QFrame::VLine), 0, 4, 7, 1);
    layGriMain->addWidget(makeLine(QFrame::VLine), 0, 6, 7, 1);

    setLayout(layGriMain);

    setMinimumSize(200, 200);
    setMaximumSize(200, 200);

    connect(&logic, SIGNAL(result(int, bool, bool, Logic::Piece)), this, SLOT(onResult(int, bool, bool, Logic::Piece)));
    //connect(eventbasedThread, &QThread::finished, &logic, &QObject::deleteLater, Qt::AutoConnection);

    eventbasedThread->start();
}

Board::~Board()
{
    if (eventbasedThread->isRunning())
    {
        eventbasedThread->quit();
        eventbasedThread->wait();
    }
}

void Board::onPieceClicked()
{
    int id = sender()->property("Id").toInt();

    disableBoard(true);
    turn = Logic::CROSS;
    QMetaObject::invokeMethod(&logic, "setCross", Qt::AutoConnection, Q_ARG(int, id));
    //logic.setCross(id);
}

void Board::onResult(int num, bool accepted, bool gameover, Logic::Piece winner)
{
    disableBoard(false);

    if (!accepted)
    {
        return;
    }

    pieces[num - 1]->setText((turn == Logic::CROSS) ? "X" : "O");
    pieces[num - 1]->setChecked(true);

    if (!gameover)
    {
        if (turn == Logic::CROSS)
        {
            disableBoard(true);
            turn = Logic::CIRCLE;
            QMetaObject::invokeMethod(&logic, "setCircle", Qt::AutoConnection);
            //logic.setCircle();
            return;
        }
        else
        {
            turn = Logic::CROSS;
            return;
        }
    }

    if (winner == Logic::CIRCLE)
        QMessageBox::information(this, "Winner", "Circle won!");
    else if (winner == Logic::CROSS)
        QMessageBox::information(this, "Winner", "Cross won!");
    else
        QMessageBox::information(this, "Winner", "No winner!");

    logic.reset();
    resetBoard();
}

QPushButton *Board::makePiece(int id)
{
    QPushButton *piece = new QPushButton;
    QFont font = piece->font();

    font.setPointSize(16);
    font.setBold(true);
    piece->setFont(font);
    piece->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
    piece->setFlat(true);
    piece->setProperty("Id", id);

    connect(piece, &QPushButton::clicked, this, &Board::onPieceClicked);

    return piece;
}

QFrame *Board::makeLine(QFrame::Shape shape)
{
    QFrame *line = new QFrame;

    line->setFrameShape(shape);
    line->setFrameShadow(QFrame::Raised);

    return line;
}

void Board::resetBoard()
{
    for (int i = 0; i < 9; i++)
        pieces[i]->setText("");
}

void Board::disableBoard(bool disable)
{
    for (int i = 0; i < 9; i++)
        pieces[i]->setDisabled(disable);
}
