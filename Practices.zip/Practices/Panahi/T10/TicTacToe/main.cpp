#include "Board.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Board ui;

    ui.show();
    return a.exec();
}
