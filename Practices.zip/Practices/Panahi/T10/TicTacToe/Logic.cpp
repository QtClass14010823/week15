#include "Logic.h"

#include <QThread>

#include <cstdlib>

Logic::Logic(QObject *parent) : QObject(parent)
{
    // Solve error on emit result: QObject::connect: Cannot queue arguments of type 'Logic::Piece'
    qRegisterMetaType<Piece>("Logic::Piece");
    //qRegisterMetaType<Piece>();

    reset();
}

void Logic::reset()
{
    emptySpaces = 9;
    winner = EMPTY;

    for (int i = 0; i < 9; i++)
        values[i] = EMPTY;
}

// Mark a cross at the given spot, -1 is auto
void Logic::setCross(int num/* = -1*/)
{
    bool finished;

    if (num == -1)
        num = suggestEmptySpot();

    if (isFull() || isSet(num))
    {
        finished = isFinished();
        emit result(num, false, finished, winner);
        return;
    }

    values[num-1] = CROSS;
    --emptySpaces;
    finished = isFinished();

    emit result(num, true, finished, winner);
}

// Mark a circle at the given spot, -1 is auto
void Logic::setCircle(int num/* = -1*/)
{
    bool finished;

    if (num == -1)
        num = suggestEmptySpot();

    if (isFull() || isSet(num))
    {
        finished = isFinished();
        emit result(num, false, finished, winner);
        return;
    }

    values[num-1] = CIRCLE;
    --emptySpaces;
    finished = isFinished();

    emit result(num, true, finished, winner);
}

bool Logic::isSet(const int num) const
{
    if (num > 9 || num < 1)
        return false;

    return values[num-1] != EMPTY;
}

int Logic::suggestEmptySpot() const
{
    if (isFull())
        return -1;

    // Providing a seed value
    srand((unsigned) time(NULL));

    // Get a random number
    int random = rand() % 9;

    while (values[random] != EMPTY)
        random = rand() % 9;

    QThread::sleep(5);

    return random + 1;
}

bool Logic::isFull() const
{
    return emptySpaces == 0;
}

// Did crosses win?
bool Logic::isCrossWinner()
{
    if (winner == CROSS)
        return true;

    if (checkForWinner(CROSS))
    {
        winner = CROSS;
        return true;
    }

    return false;
}

// Did circles win?
bool Logic::isCircleWinner()
{
    if (winner == CIRCLE)
        return true;

    if (checkForWinner(CIRCLE))
    {
        winner = CIRCLE;
        return true;
    }

    return false;
}

// Is the game on or not?
bool Logic::isFinished()
{
    return isFull() || isCrossWinner() || isCircleWinner();
}

bool Logic::checkForWinner(Piece player) const
{
    // check rows
    for (int i = 0; i < 9; i += 3)
        if (values[i] == player &&
                values[i+1] == player &&
                values[i+2] == player) {
            return true;
        }

    // check columns
    for (int i = 0; i < 3; ++i)
        if (values[i] == player &&
                values[i+3] == player &&
                values[i+6] == player) {
            return true;
        }

    // check diagonals
    if (values[0] == player &&
            values[4] == player &&
            values[8] == player)
        return true;

    if (values[2] == player &&
            values[4] == player &&
            values[6] == player)
        return true;

    return false;
}
