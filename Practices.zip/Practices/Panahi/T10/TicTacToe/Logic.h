#ifndef LOGIC_H
#define LOGIC_H

#include <QObject>

class Logic : public QObject
{
    Q_OBJECT
public:
    enum Piece
    {
        EMPTY = 0,
        CROSS,
        CIRCLE
    };

    explicit Logic(QObject *parent = nullptr);

    void reset();


public slots:
    // Mark a cross at the given spot
    void setCross(int num = -1);

    // Mark a circle at the given spot
    void setCircle(int num = -1);

signals:
    void result(int num, bool accepted, bool gameover, Logic::Piece winner);

private:
    Piece values[9];
    int emptySpaces;
    Piece winner;

    // Check if a spot is marked or not
    bool isSet(const int num) const;

    int suggestEmptySpot() const;

    bool isFull() const;

    // Did crosses win?
    bool isCrossWinner();

    // Did circles win?
    bool isCircleWinner();

    // Is the game on or not?
    bool isFinished();

    bool checkForWinner(Piece player) const;
};

Q_DECLARE_METATYPE(Logic::Piece)

#endif // LOGIC_H
