#ifndef BOARD_H
#define BOARD_H

#include <QWidget>
#include <QFrame>

#include "Logic.h"

QT_BEGIN_NAMESPACE
class QPushButton;
class QThread;
QT_END_NAMESPACE

class Board : public QWidget
{
    Q_OBJECT
public:
    explicit Board(QWidget *parent = nullptr);
    ~Board();

signals:

private slots:
    void onPieceClicked();
    void onResult(int num, bool accepted, bool gameover, Logic::Piece winner);

private:
    QPushButton *pieces[9];
    Logic logic;
    Logic::Piece turn;
    QThread *eventbasedThread;

    QPushButton *makePiece(int id);
    QFrame *makeLine(QFrame::Shape shape);
    void resetBoard();
    void disableBoard(bool disable);
};

#endif // BOARD_H
