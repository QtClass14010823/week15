#ifndef SAFEQUEUE_H
#define SAFEQUEUE_H

#include <QMutex>

#include "Global.h"

class SafeQueue
{
public:
    SafeQueue();
    bool add(int n);
    bool remove(int *n);
    void display();

private:
    int queue[QUEUE_SIZE], n, front, rear;
    QMutex mutex;
};

#endif // SAFEQUEUE_H
