#include "SafeQueue.h"

#include <iostream>

using namespace std;

SafeQueue::SafeQueue() :
    n(QUEUE_SIZE), front(-1), rear(-1)
{
}

bool SafeQueue::add(int n)
{
    mutex.lock();
    // Queue Overflow
    if (rear == n - 1)
    {
        mutex.unlock();
        return false;
    }
    else
    {
        // Insert the element in queue
        if (front == - 1)
            front = 0;

        rear++;
        queue[rear] = n;
        mutex.unlock();

        return true;
    }
}

bool SafeQueue::remove(int *n)
{
    mutex.lock();
    // Queue Underflow
    if (front == - 1 || front > rear)
    {
        mutex.unlock();
        return false;
    }
    // Element deleted from queue
    else
    {
        *n = queue[front];
        front++;
        mutex.unlock();

        return true;
    }
}

void SafeQueue::display()
{
    mutex.lock();
    // Queue is empty
    if (front == - 1)
    {
        mutex.unlock();
        cout << "Queue is empty." << endl;
    }
    else
    {
        cout << "Queue elements are:" << endl;

        for (int i = front; i <= rear; i++)
            cout << queue[i] << " ";
        mutex.unlock();

        cout << endl;
    }
}
