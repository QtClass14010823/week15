#include "CirQueue.h"
#include "QMessageBox"

CirQueue::CirQueue(QObject *parent) : QObject(parent)
{
    front = -1;
    rear = -1;
    SIZE=100;
}
bool CirQueue::isFull()
{
    if ((front == rear + 1) || (front == 0 && rear == SIZE - 1))
        return true;
    return false;
}
bool CirQueue::isEmpty()
{
    if (front == -1)
        return true;
    return false;
}
void CirQueue::add2queue(int element)
{
    if (isFull())
        QMessageBox::critical(nullptr,"Error","Queue is full!!",QMessageBox::Ok);
    else
    {
        mutex.lock();
        if (front == -1)
            front = 0;
        rear = (rear + 1) % SIZE;
        items[rear] = element;
        mutex.unlock();
        QMessageBox::information(nullptr,"Info",tr("%1 Inserted").arg(element),QMessageBox::Ok);
    }
}
int CirQueue::delFromQueue()
{
    int element;
    if (isEmpty())
    {
        QMessageBox::critical(nullptr,"Info","Queue is empty !!",QMessageBox::Ok);
        return (-1);
    }
    else
    {
        mutex.lock();
        element = items[front];
        if (front == rear)
        {
            front = -1;
            rear = -1;
        }
        else
        {
            front = (front + 1) % SIZE;
        }
        mutex.unlock();
        QMessageBox::information(nullptr,"Info",tr("%1 Deleted").arg(element),QMessageBox::Ok);
        return (element);
    }
}
