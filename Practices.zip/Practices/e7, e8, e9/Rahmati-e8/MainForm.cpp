#include "MainForm.h"

MainForm::MainForm(QWidget *parent) : QWidget(parent)
{
    cirQueue=new CirQueue();

    bLayout = new QGridLayout(this);
    lblAdd = new QLabel("Add Item:", this);
    lblDel = new QLabel("Delete Item:", this);
    lnEditAdd = new QLineEdit(this);
    lnEditDel = new QLineEdit(this);
    btnAdd = new QPushButton("Click To Add", this);
    btnDel = new QPushButton("Click To Del", this);


    bLayout->addWidget(lblAdd, 0, 0);
    bLayout->addWidget(lblDel, 1, 0);
    bLayout->addWidget(lnEditAdd, 0, 1);
    bLayout->addWidget(lnEditDel, 1, 1);
    bLayout->addWidget(btnAdd, 0, 2);
    bLayout->addWidget(btnDel, 1, 2);

    this->setLayout(bLayout);

    this->setWindowTitle("Circular Queue project");
    connect(btnAdd, &QPushButton::clicked, this, &MainForm::onAddClicked);
    connect(btnDel, &QPushButton::clicked, this, &MainForm::onDelClicked);
    lnEditDel->setReadOnly(true);
}
MainForm::~MainForm()
{
}
void MainForm::onAddClicked()
{
    if(lnEditAdd->text().length()<1)    return;
    bool isNumber=false;
    int element=lnEditAdd->text().toInt(&isNumber,10);
    if(!isNumber)    return;
    cirQueue->add2queue(element);
}
void MainForm::onDelClicked()
{
    int element=cirQueue->delFromQueue();
    lnEditDel->setText(QString::number(element));
}
