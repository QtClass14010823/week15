#include "Form.h"
#include "worker.h"


Form::Form(QWidget *parent) : QWidget(parent)
{
    bLayout = new QGridLayout(this);
    btnRun = new QPushButton("  Run  ", this);
    bLayout->addWidget(btnRun, 3, 0, 1, 3);
    this->setLayout(bLayout);
    this->setWindowTitle("Prime Count & Semaphore");
    connect(btnRun, &QPushButton::clicked, this, &Form::Run);
 }


void Form::Run()
{
    for(int i=1;i<=10;i++)
    {
        // Create new thread
        QThread *workerThread = new QThread(this);
        // Create new instance of worker class
        Worker *worker = new Worker();
        // Send the process of every 1000 numbers to the new thread
        worker->setParams(QString("file%0.txt").arg(i),1+(i-1)*1000,i*1000);
        worker->moveToThread(workerThread);
        connect(workerThread, &QThread::finished, worker, &QObject::deleteLater, Qt::AutoConnection);
        workerThread->start();
        QMetaObject::invokeMethod(worker, "doWork", Qt::AutoConnection);

    }


}

