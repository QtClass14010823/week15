#include "Mainwindow.h"

#include <QFile>
#include <QMessageBox>

Contact contact;
QString strContactCount="Contact Count:  ";
QString strFileName="contact.bin";

void MainWindow::get_total_contact()
{
    QFile file(strFileName);
    file.open(QIODevice::ReadOnly);
    QDataStream in(&file);
    int i=0;
    while (!in.atEnd()) {
        in.readRawData((char*)&contact,sizeof(contact));
        i++;
    }
    file.close();
    this->lblCount->setText(strContactCount+QString::number(i));
}
void MainWindow::find_contact()
{
    if(leFind->text().length()<1)
    {
        return;
    }
    QFile file(strFileName);
    file.open(QIODevice::ReadOnly);
    QDataStream in(&file);
    bool found=false;
    while (!in.atEnd()) {
        in.readRawData((char*)&contact,sizeof(contact));
        if(strcmp(contact.name,leFind->text().toLocal8Bit())==0)
        {
            QString strTmp="Name: "+leFind->text()+"\nTel: "+QString::number(contact.tel);
            QMessageBox::information(this,"Contact Find",strTmp,QMessageBox::Ok);
            found=true;
        }
    }
    file.close();
    if(!found)
    {
        QMessageBox::critical(this,"Error","Not Found!!!",QMessageBox::Ok);
    }
}
void MainWindow::btnAdd_clicked()
{
    if(leName->text().length()<1||leTel->text().length()<1)
    {
        QMessageBox::critical(this,"Error","Name or Tel is empty!!!",QMessageBox::Ok);
        return;
    }

    QFile file(strFileName);
    file.open(QIODevice::Append);
    QDataStream out(&file);

    QByteArray ba = leName->text().toLocal8Bit();
    ba.truncate(19);
    strncpy(contact.name,ba.data(),20);

    bool resTel=false;
    contact.tel=leTel->text().toUInt(&resTel,10);

    if(resTel==false)
    {
        QMessageBox::critical(this,"Error","Tel is not a valid number!!!",QMessageBox::Ok);
        return;
    }


    int resSave=out.writeRawData((char*)&contact,sizeof(contact));
    file.close();
    if(resSave==-1)
    {
        QMessageBox::critical(this,"Error","Contact Not Saved!!!",QMessageBox::Ok);
    }
    else
    {
        QMessageBox::information(this,"Information","Contact saved.",QMessageBox::Ok);
        leName->setText("");
        leTel->setText("");
        get_total_contact();
    }
}
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)

{

    setWindowTitle("Contact");
    setCentralWidget(window);
    vl->addWidget(gbInfo);
    vl->addWidget(gbAdd);
    vl->addWidget(gbFind);
    window->setLayout(vl);
    ///////// info
    QHBoxLayout *hlInfo=new QHBoxLayout(gbInfo);
    lblCount->setText(strContactCount);
    hlInfo->addWidget(lblCount);
    get_total_contact();

    ///// Add
    QGridLayout *gl=new QGridLayout(gbAdd);
    QPushButton *btnAdd=new QPushButton(gbAdd);

    btnAdd->setText("Add");

//    leTel->setInputMask("99999999999");

    gl->addWidget(lblName,0,0,1,1);
    gl->addWidget(leName,0,1,1,1);
    gl->addWidget(lblTel,1,0,1,1);
    gl->addWidget(leTel,1,1,1,1);
    gl->addWidget(btnAdd,2,2,1,1);

    lblName->setText("Name: ");
    lblTel->setText("Tel: ");

    gbInfo->setTitle("Info");
    gbAdd->setTitle("Add");
    gbFind->setTitle("Find");
    connect(btnAdd,&QPushButton::clicked,this,&MainWindow::btnAdd_clicked);

    /// Find
    QHBoxLayout *hlFind=new QHBoxLayout(gbFind);
    QPushButton *btnFind=new QPushButton(gbFind);

    lblFind->setText("Name: ");
    btnFind->setText("Find");
    hlFind->addWidget(lblFind);
    hlFind->addWidget(leFind);
    hlFind->addWidget(btnFind);
    connect(btnFind,&QPushButton::clicked,this,&MainWindow::find_contact);
}

MainWindow::~MainWindow()
{

}

