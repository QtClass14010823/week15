#include "Form.h"

#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>
#include <QDebug>

Form::Form(QWidget *parent) : QWidget(parent)
{
    bLayout = new QVBoxLayout(this);
    iGrp = new QGroupBox("Info",this);
    iLayout = new QGridLayout(iGrp);
    aGrp = new QGroupBox("Add",this);
    aLayout = new QGridLayout(aGrp);
    fGrp = new QGroupBox("Find",this);
    fLayout = new QGridLayout(fGrp);

    bLayout->addWidget(iGrp,1);
    bLayout->addWidget(aGrp,2);
    bLayout->addWidget(fGrp,2);

    lblInfo = new QLabel("Count = 0",iGrp);
    iLayout->addWidget(lblInfo);

    lblAName = new QLabel("Name:",aGrp);
    lblATel = new QLabel("Telephone:",aGrp);
    lnEditName = new QLineEdit(aGrp);
    lnEditTel = new QLineEdit(aGrp);
    lnEditName->setMaxLength(20);
    lnEditTel->setMaxLength(15);
    btnAdd = new QPushButton("Add",aGrp);
    aLayout->addWidget(lblAName,0,0);
    aLayout->addWidget(lnEditName,0,1);
    aLayout->addWidget(lblATel,1,0);
    aLayout->addWidget(lnEditTel,1,1);
    aLayout->addWidget(btnAdd,1,2);

    lblFName = new QLabel("Name:",fGrp);
    lnEditFName = new QLineEdit(fGrp);
    lnEditFName->setMaxLength(20);
    btnFind = new QPushButton("Find",fGrp);
    fLayout->addWidget(lblFName,0,0);
    fLayout->addWidget(lnEditFName,0,1);
    fLayout->addWidget(btnFind,0,2);


//    this->setLayout(bLayout);

    this->setWindowTitle("Phone Book");
    connect(btnAdd, &QPushButton::clicked, this, &Form::onAddClicked);
    connect(btnFind, &QPushButton::clicked, this, &Form::onFindClicked);
    tmp.setFileName("data.txt");
    if(tmp.exists())
    {
  //      QMessageBox::information(this, "Information", "Data.txt is exists");
        tmp.open(QIODevice::ReadWrite);
    }
    else
    {
       tmp.open(QIODevice::ReadWrite);

    }
    lblInfo->setText("Contact Count="+QString::number(tmp.size()/35));

}

Form::~Form(){
 tmp.close();
// QMessageBox::information(this, "Information", "Data.txt is closed.");
}

void Form::onAddClicked()
{
    QString str;
    char buff[100];
    if(tmp.isOpen())
    {
      tmp.seek(tmp.size());
      str=lnEditName->text();
      while(str.size()!=0 && str.size()<20)
        str+=" ";
      strcpy(buff,str.toStdString().c_str());
      tmp.write(buff,str.size());

      str=lnEditTel->text();
      while(str.size()!=0 && str.size()<15)
       str+=" ";
      strcpy(buff,str.toStdString().c_str());
      tmp.write(buff,str.size());
      lblInfo->setText("Contact Count="+QString::number(tmp.size()/35));
      QMessageBox::information(this, "Information", lnEditName->text()+" was Saved.");
    }

}

void Form::onFindClicked()
{
    QString str;
    char buff[21];
    bool find=false;
    str=lnEditFName->text();
    while(str.size()!=0 && str.size()<20)
     str+=" ";
    tmp.seek(0);
    while(find==false && tmp.atEnd()==false)
    {
        tmp.read(buff,20);
        buff[20]=0;
        if(strcmp(buff,str.toStdString().c_str())==0)
        {
          lnEditName->setText(str);
          tmp.read(buff,15);
          buff[15]=0;
          str= QString::fromLocal8Bit(buff);
       //   qDebug() << str;
          lnEditTel->setText(str);
          find=true;
          QMessageBox::information(this, "Information", " Found.");
        }
        else
         tmp.read(buff,15);
    }
    if(!find)
        QMessageBox::information(this, "Information", " Not Found.");
}

