#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>
#include <QLayout>
#include <QVBoxLayout>
#include <QGroupBox>
#include <QFile>

class Form : public QWidget
{
    Q_OBJECT
public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();
signals:

private slots:
    void onAddClicked();
    void onFindClicked();
 //   void onCopyClicked();

private:
    QVBoxLayout *bLayout;
    QGridLayout *iLayout,*aLayout,*fLayout;
    QGroupBox *iGrp,*aGrp,*fGrp;
    QLabel *lblInfo,*lblAName, *lblATel,*lblFName;
    QLineEdit *lnEditName, *lnEditTel,*lnEditFName;
    QPushButton *btnAdd, *btnFind;
    QFile tmp;
};



#endif // FORM_H
