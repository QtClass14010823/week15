#include "Form.h"
#include <QFile>
#include <QMessageBox>
#include <QTextStream>
#include <iostream>

using namespace std;

Form::Form(QWidget *parent) : QWidget(parent)
{
    /////////////////////////  initializing (start) ///////////////////////////////////
    grBoxInfo.setTitle("Info");
    lblCount.setText("Contact Count:");
    layInfo.addWidget(&lblCount,0,0);
    lblCnt.setText("0");
    layInfo.addWidget(&lblCnt,0,1);
    grBoxInfo.setLayout(&layInfo);
    layout.addWidget(&grBoxInfo);

    grBoxAdd.setTitle("Add");
    lblName.setText("Name");
    lblTel.setText("Tel");
    butAdd.setText("Add");
    layAdd.addWidget(&lblName,0,0);
    layAdd.addWidget(&ledtName,0,1);
    layAdd.addWidget(&lblTel,1,0);
    layAdd.addWidget(&ledtTel,1,1);
    layAdd.addWidget(&butAdd,1,2);
    grBoxAdd.setLayout(&layAdd);
    layout.addWidget(&grBoxAdd);

    grBoxFind.setTitle("Find");
    lblfName.setText("Name");
    butFind.setText("Find");
    layFind.addWidget(&lblfName,0,0);
    layFind.addWidget(&ledtfName,0,1);
    layFind.addWidget(&butFind,0,2);
    grBoxFind.setLayout(&layFind);
    layout.addWidget(&grBoxFind);

    butQuit.setText("Exit");
    layQuit.addWidget(&butQuit,1,2);
    layout.addLayout(&layQuit);

    this->setLayout(&layout);

    this->setWindowTitle("contacts");
   /////////////////////////  initializing (end) ///////////////////////////////////

    /////////////////////////  connecting signal & slots (start) ///////////////////////////////////
    connect(&butAdd,  &QPushButton::clicked, this, &Form::onAddClicked);
    connect(&butFind, &QPushButton::clicked, this, &Form::onFindClicked);
    connect(&butQuit, &QPushButton::clicked, this, &Form::close);
    /////////////////////////  connecting signal & slots (end) ///////////////////////////////////

    /////////////////////////  file loading (start) ///////////////////////////////////
    QFile file("file.dat");
    if (!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::information(this,"Error","Failed to open the file for reading!");
        return;
    }
    qint64 fSize=file.size();
    lblCnt.setText(QString::number((int)(fSize/sizeof(ContactInfo))));
    if(fSize >= sizeof(ContactInfo))
    {
        ContactInfo sCInfo;
        if(file.read((char*) &sCInfo,sizeof(ContactInfo))!=sizeof(ContactInfo))
        {
            file.close();
            return;
        }
        ledtName.setText(sCInfo.cName);
        ledtTel.setText(QString::number(sCInfo.iTel));
    }

   /////////////////////////  file loading (end) ///////////////////////////////////



}

void Form::onAddClicked()
{
    QFile file("file.dat");
    if (!file.open(QIODevice::Append))
    {
        QMessageBox::information(this,"Error","Failed to open the file for writing!");
           return;
    }
    ContactInfo sCInfo;
    strcpy(sCInfo.cName,ledtName.text().toStdString().c_str());
    sCInfo.iTel=ledtTel.text().toInt();
    file.write(sCInfo.cName, sizeof (sCInfo.cName));
    file.write((char*)&sCInfo.iTel, sizeof (int));
    file.close();
    lblCnt.setText(QString::number(lblCnt.text().toInt()+1));

}

void Form::onFindClicked()
{
    QString fname = ledtfName.text();
    if(fname.isEmpty())
    {
        QMessageBox::information(this,"Error","Please Enter name!");
        return;
    }
    QFile file("file.dat");
    if (!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::information(this,"Error","Failed to open the file for reading!");
        return;
    }

    while(!file.atEnd())
    {
        ContactInfo sCInfo;
        file.read((char*) &sCInfo,sizeof(ContactInfo));

        if(!fname.compare(sCInfo.cName))
        {
            ledtName.setText(sCInfo.cName);
            ledtTel.setText(QString::number(sCInfo.iTel));
            return;
        }

    }
    QMessageBox::information(this,"Error","Contact not found!");

}

