#include "widget.h"
#include <QMessageBox>
#include <QDebug>
#include <QCoreApplication>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{

    MainGrid = new QGridLayout(this);
    Lbl_Length = new QLabel(this);
    Lbl_Weight = new QLabel(this);
    Lbl_Age = new QLabel(this);
//    Lbl_Length_Info = new QLabel(this);
//    Lbl_Weight_Info = new QLabel(this);
//    Lbl_Age_Info = new QLabel(this);



    LnEdit_Length = new QLineEdit(this);
    LnEdit_Weight = new QLineEdit(this);
    LnEdit_Age = new QLineEdit(this);

    BtnCalc = new QPushButton(this);
    BtnExit = new QPushButton(this);



    MainGrid->addWidget(Lbl_Length, 0, 0);
    MainGrid->addWidget(LnEdit_Length, 0, 1);

    MainGrid->addWidget(Lbl_Weight, 1, 0);
    MainGrid->addWidget(LnEdit_Weight, 1, 1);

    MainGrid->addWidget(Lbl_Age, 2, 0);
    MainGrid->addWidget(LnEdit_Age, 2, 1);

    MainGrid->addWidget(BtnCalc, 4, 0);
    MainGrid->addWidget(BtnExit, 4, 1);
    this->setLayout(MainGrid);

    Translate_Ui();
    connect(BtnCalc, &QPushButton::clicked, this, &Widget::on_BtnOk_Clicked);
    QObject::connect(BtnExit,SIGNAL(clicked(bool)),this,SLOT(close()));


}

void Widget::Translate_Ui()
{
    this->setWindowTitle(QCoreApplication::translate("Widget", "BMI", nullptr));
    Lbl_Length->setText(QCoreApplication::translate("Widget", "Length:", nullptr));
    Lbl_Weight->setText(QCoreApplication::translate("Widget", "Weight:", nullptr));
    Lbl_Age->setText(QCoreApplication::translate("Widget", "Age:", nullptr));
    BtnCalc->setText(QCoreApplication::translate("Widget","Calculate",nullptr));
    BtnExit->setText(QCoreApplication::translate("Widget","Exit",nullptr));

}
void Widget::on_BtnOk_Clicked()
{
    if(LnEdit_Age->text()!=nullptr && LnEdit_Length->text()!=nullptr && LnEdit_Weight!=nullptr)
    {
       float W,L,Bmi;
      W=LnEdit_Weight->text().toFloat();
      L=LnEdit_Length->text().toFloat()/100;
      Bmi=W/(L*L);
      QMessageBox::information(this, tr("Information of BMI"),QString::number(Bmi));

    }
    else
    {
        msg =new QMessageBox(this);
        msg->setText(tr("Some data is empty!"));
        msg->show();

    }
    LnEdit_Age->clear();
    LnEdit_Length->clear();
    LnEdit_Weight->clear();


}


Widget::~Widget()
{
}

