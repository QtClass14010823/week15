#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include<QPushButton>
#include<QLineEdit>
#include<QLabel>
#include<QGridLayout>
#include<QMessageBox>

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_BtnOk_Clicked();

private:

  QPushButton *BtnExit,*BtnCalc;
  QLineEdit  *LnEdit_Length,*LnEdit_Age,*LnEdit_Weight;
  QLabel   *Lbl_Length,*Lbl_Age,*Lbl_Weight;
  QLabel   *Lbl_Length_Info,*Lbl_Age_Info,*Lbl_Weight_Info;
  QGridLayout *MainGrid;
  QMessageBox *msg;

  void Translate_Ui();


};
#endif // WIDGET_H
