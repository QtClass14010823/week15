#ifndef W3_H
#define W3_H

#include <QWidget>
#include <QPushButton>
#include <QGridLayout>
#include <QSpinBox>
#include <QLabel>

class W3 : public QWidget
{
    Q_OBJECT
public:
    explicit W3(QWidget *parent = nullptr);
    int getHeight();
private slots:

private:
    QPushButton *btnMan,*btnWomen;
    QSpinBox *spinBox;
    QLabel *lblInfo;

    int height;

signals:

};

#endif // W3_H
