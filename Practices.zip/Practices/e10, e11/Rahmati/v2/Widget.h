#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QStackedWidget>
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>

#include "W1.h"
#include "W2.h"
#include "W3.h"
#include "W4.h"
#include "W5.h"
#include "W6.h"

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
private:
    W1 *w1;
    W2 *w2;
    W3 *w3;
    W4 *w4;
    W5 *w5;
    W6 *w6;
    QStackedWidget *sw;
    QGridLayout *gl1;
    QLabel *lbl1,*lblBmi,*lblBmr;
    QPushButton *btnBack,*btnNext;
private slots:
    void on_btnBack_clicked();
    void on_btnNext_clicked();

};
#endif // WIDGET_H
