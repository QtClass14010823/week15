#include "Widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    resize(800,400);
    setWindowTitle(tr("BMI & BMR Calculator"));

    QFont myFont("Ubuntu", 20, QFont::Bold);

    gl1 = new QGridLayout(this);
    btnBack=new QPushButton(tr("Back"),this);
    btnNext=new QPushButton(tr("Next"),this);

    sw = new QStackedWidget;


    gl1->addWidget(sw,0,0,1,2);
    gl1->addWidget(btnBack,1,1);
    gl1->addWidget(btnNext,1,0);

    //sw->addWidget(w1=new W1);
    sw->addWidget(w2=new W2);
    sw->addWidget(w3=new W3);
    sw->addWidget(w4=new W4);
    sw->addWidget(w5=new W5);
    sw->addWidget(w6=new W6);

    sw->setCurrentIndex(0);

    this->setLayout(gl1);

    connect(btnBack,SIGNAL(clicked()),SLOT(on_btnBack_clicked()));
    connect(btnNext,SIGNAL(clicked()),SLOT(on_btnNext_clicked()));
}

Widget::~Widget()
{
}
void Widget::on_btnBack_clicked()
{
    if(sw->currentIndex()>0)
        sw->setCurrentIndex(sw->currentIndex()-1);
}
void Widget::on_btnNext_clicked()
{
    if(sw->currentIndex()<sw->count()-1)
        sw->setCurrentIndex(sw->currentIndex()+1);

    if(sw->currentIndex()==4)
    {
        w6->setAge(w5->getAge());
        w6->setGender(w2->getGender());
        w6->setHeight(w3->getHeight());
        w6->setWeight(w4->getWeight());
        w6->calc();
    }
}

