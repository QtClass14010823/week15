#include "W2.h"

#include <QGridLayout>

W2::W2(QWidget *parent) : QWidget(parent)
{
    resize(800,400);
    gender=1;//male
    btnMan=new QPushButton("", this);
    btnWomen=new QPushButton("", this);
    QGridLayout *gl1 = new QGridLayout(this);

    QPixmap pixM(":pic/pic/man.jpg");
    QSize mySizeM(pixM.size().width(),pixM.size().height());
    pixM = pixM.scaled(mySizeM,Qt::KeepAspectRatio);
    btnMan->resize(pixM.width(),pixM.height());
    QIcon ButtonIcon(pixM);
    btnMan->setIcon(ButtonIcon);
    btnMan->setIconSize(pixM.rect().size());

    QPixmap pixWomen(":pic/pic/women.jpg");
    QSize mySizeW(pixWomen.size().width(),pixWomen.size().height());
    pixWomen = pixWomen.scaled(mySizeW,Qt::KeepAspectRatio);
    btnWomen->resize(pixWomen.width(),pixWomen.height());
    QIcon ButtonIconW(pixWomen);
    btnWomen->setIcon(ButtonIconW);
    btnWomen->setIconSize(pixWomen.rect().size());

    lblInfo=new QLabel(this);
    lblInfo->setText(tr("Select Your Gender:"));

    gl1->addWidget(lblInfo,0,0,1,2);
    gl1->addWidget(btnMan,1,0);
    gl1->addWidget(btnWomen,1,1);

    this->setLayout(gl1);

    connect(btnMan,SIGNAL(clicked()),SLOT(on_btnMan_clicked()));
    connect(btnWomen,SIGNAL(clicked()),SLOT(on_btnWomen_clicked()));

}
void W2::on_btnMan_clicked()
{
    gender=1;
}
void W2::on_btnWomen_clicked()
{
    gender=0;
}
int W2::getGender()
{
    return gender;
}
