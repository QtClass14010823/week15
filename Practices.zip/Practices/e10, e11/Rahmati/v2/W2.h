#ifndef W2_H
#define W2_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>

class W2 : public QWidget
{
    Q_OBJECT
public:
    explicit W2(QWidget *parent = nullptr);
    int getGender();

signals:
private slots:
    void on_btnMan_clicked();
    void on_btnWomen_clicked();

private:
    QPushButton *btnMan,*btnWomen;
    QLabel *lblInfo;
    int gender;

};

#endif // W2_H
