#ifndef W6_H
#define W6_H

#include <QWidget>
#include <QLabel>
#include <QGridLayout>

class W6 : public QWidget
{
    Q_OBJECT
public:
    explicit W6(QWidget *parent = nullptr);
    void setGender(int gender);
    void setHeight(int height);
    void setWeight(int weight);
    void setAge(int age);
    void calc();

signals:
private:
    QLabel *lbl1,*lblBmi,*lblBmr;
    int gender;
    int height;
    int weight;
    int age;
    QGridLayout *gl1;
};

#endif // W6_H
