#ifndef W4_H
#define W4_H

#include <QWidget>
#include <QPushButton>
#include <QGridLayout>
#include <QSpinBox>
#include <QLabel>

class W4 : public QWidget
{
    Q_OBJECT
public:
    explicit W4(QWidget *parent = nullptr);
    int getWeight();

signals:
private slots:

private:
    QPushButton *btnMan,*btnWomen;
    QSpinBox *spinBox;
    QLabel *lblInfo;

    int weight;

};

#endif // W4_H
