#include "W1.h"

W1::W1(QWidget *parent) : QWidget(parent)
{
    resize(800,400);
    setWindowTitle(tr("BMI & BMR Calculator"));

    QFont myFont("Ubuntu", 20, QFont::Bold);

    lbl1 = new QLabel(this);
    lbl1->setFont(myFont);

    QPixmap pix(":/pic/pic/images.jpeg");
    QSize mySize(800,400);
    pix = pix.scaled(mySize,Qt::IgnoreAspectRatio);
    lbl1->resize(pix.width(),pix.height());
    lbl1->setPixmap(pix);

}
