<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>W1</name>
    <message>
        <location filename="../W1.cpp" line="6"/>
        <source>BMI &amp; BMR Calculator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>W2</name>
    <message>
        <location filename="../W2.cpp" line="30"/>
        <source>Select Your Gender:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>W3</name>
    <message>
        <location filename="../W3.cpp" line="28"/>
        <source>Enter Your Height:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>W4</name>
    <message>
        <location filename="../W4.cpp" line="24"/>
        <source>Enter Your Weight:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>W5</name>
    <message>
        <location filename="../W5.cpp" line="24"/>
        <source>Enter Your Age:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>W6</name>
    <message>
        <location filename="../W6.cpp" line="53"/>
        <source>Your BMI: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../W6.cpp" line="67"/>
        <source>Your BMR: %1 Kkal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <location filename="../Widget.cpp" line="7"/>
        <source>BMI &amp; BMR Calculator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Widget.cpp" line="12"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Widget.cpp" line="13"/>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
