<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fa_IR">
<context>
    <name>W1</name>
    <message>
        <location filename="../W1.cpp" line="6"/>
        <source>BMI &amp; BMR Calculator</source>
        <translation>محاسبه شاخص توده بدنی و اندازه متابولیسم پایه</translation>
    </message>
</context>
<context>
    <name>W2</name>
    <message>
        <location filename="../W2.cpp" line="30"/>
        <source>Select Your Gender:</source>
        <translation>جنسیت خود را وارد کنید:</translation>
    </message>
</context>
<context>
    <name>W3</name>
    <message>
        <source>Enter Your Height :</source>
        <translation type="vanished">قد خود را وارد کنید:</translation>
    </message>
    <message>
        <location filename="../W3.cpp" line="28"/>
        <source>Enter Your Height:</source>
        <translation>قد خود را وارد کنید:</translation>
    </message>
</context>
<context>
    <name>W4</name>
    <message>
        <source>Enter Your Weight :</source>
        <translation type="vanished">وزن خود را وارد کنید:</translation>
    </message>
    <message>
        <location filename="../W4.cpp" line="24"/>
        <source>Enter Your Weight:</source>
        <translation>وزن خود را وارد کنید:</translation>
    </message>
</context>
<context>
    <name>W5</name>
    <message>
        <source>Enter Your Age :</source>
        <translation type="vanished">سن خود را وارد کنید:</translation>
    </message>
    <message>
        <location filename="../W5.cpp" line="24"/>
        <source>Enter Your Age:</source>
        <translation>سن خود را وارد کنید:</translation>
    </message>
</context>
<context>
    <name>W6</name>
    <message>
        <location filename="../W6.cpp" line="53"/>
        <source>Your BMI: %1</source>
        <translation>شاخص توده بدنی شما: %1</translation>
    </message>
    <message>
        <location filename="../W6.cpp" line="67"/>
        <source>Your BMR: %1 Kkal</source>
        <translation>اندازه متابولیسم پایه: %1</translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <location filename="../Widget.cpp" line="7"/>
        <source>BMI &amp; BMR Calculator</source>
        <translation>محاسبه شاخص توده بدنی و اندازه متابولیسم پایه</translation>
    </message>
    <message>
        <location filename="../Widget.cpp" line="12"/>
        <source>Back</source>
        <translation>قبلی</translation>
    </message>
    <message>
        <location filename="../Widget.cpp" line="13"/>
        <source>Next</source>
        <translation>بعدی</translation>
    </message>
</context>
</TS>
