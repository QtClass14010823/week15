#include "W5.h"

W5::W5(QWidget *parent) : QWidget(parent)
{
    resize(800,400);
    age=0;//unknown
    QGridLayout *gl1 = new QGridLayout(this);

    spinBox=new QSpinBox(this);
    spinBox->setSuffix(" Years");
    spinBox->setRange(7,120);
    spinBox->setValue(35);
    QFont myFont("Ubuntu", 20, QFont::Bold);
    spinBox->setFont(myFont);

    QLabel *lbl1 = new QLabel(this);
    QPixmap pix(":pic/pic/age.jpeg");
    QSize mySize(800,400);
    pix = pix.scaled(mySize,Qt::IgnoreAspectRatio);
    lbl1->resize(pix.width(),pix.height());
    lbl1->setPixmap(pix);

    lblInfo=new QLabel(this);
    lblInfo->setText(tr("Enter Your Age:"));

    gl1->addWidget(lblInfo,0,0);
    gl1->addWidget(lbl1, 1, 0);
    gl1->addWidget(spinBox,2,0);

    this->setLayout(gl1);


}
int W5::getAge()
{
    age=spinBox->value();
    return age;
}
