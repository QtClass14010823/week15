#include "W6.h"

#include <QtMath>

W6::W6(QWidget *parent) : QWidget(parent)
{
    resize(800,400);
    QFont myFont("Ubuntu", 20, QFont::Bold);

    gl1 = new QGridLayout(this);

    lbl1 = new QLabel(this);
    lbl1->setFont(myFont);

    lblBmr = new QLabel(this);
    lblBmr->setFont(myFont);

    lblBmi = new QLabel(this);
    lblBmi->setFont(myFont);


    QPixmap pix(":/pic/pic/BMI-res6.jpg");
    QSize mySize(800,400);
    pix = pix.scaled(mySize,Qt::IgnoreAspectRatio);
    lbl1->resize(pix.width(),pix.height());
    lbl1->setPixmap(pix);

    gl1->addWidget(lbl1, 0,0);
    gl1->addWidget(lblBmi, 1,0);
    gl1->addWidget(lblBmr, 2,0);

    this->setLayout(gl1);
}
void W6::setGender(int gender)
{
    this->gender=gender;
}
void W6::setHeight(int height)
{
    this->height=height;
}
void W6::setWeight(int weight)
{
    this->weight=weight;
}
void W6::setAge(int age)
{
    this->age=age;
}
void W6::calc()
{
    float bmr=0,bmi=weight/ qPow(height/100.,2);
    lblBmi->setText(tr("Your BMI: %1").arg(bmi));

    if(gender==0)
    {
        bmr=(10*weight)+(6.25*height)-(5*age)-161;
    }
    else if(gender==1)
    {
        bmr=(10*weight)+(6.25*height)-(5*age)+5;
    }
    else
    {

    }
    lblBmr->setText(tr("Your BMR: %1 Kkal").arg(bmr));


}
