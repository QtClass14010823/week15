#ifndef W5_H
#define W5_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QGridLayout>
#include <QSpinBox>

class W5 : public QWidget
{
    Q_OBJECT
public:
    explicit W5(QWidget *parent = nullptr);
    int getAge();

signals:
private:
    QPushButton *btnMan,*btnWomen;
    QSpinBox *spinBox;
    QLabel *lblInfo;

    int age;

};

#endif // W5_H
