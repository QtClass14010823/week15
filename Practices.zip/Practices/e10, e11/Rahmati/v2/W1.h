#ifndef W1_H
#define W1_H

#include <QWidget>
#include <QLabel>

class W1 : public QWidget
{
    Q_OBJECT
public:
    explicit W1(QWidget *parent = nullptr);

signals:
private:
    QLabel *lbl1;

};

#endif // W1_H
