<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>Qdlg1</name>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Your Gender :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Qdlg2</name>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Your Height :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Qdlg3</name>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Your Weight :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Qdlg4</name>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Your Age :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <source>Your BMI: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BMI &amp; BMR Calculator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your BMR: %1 Kcal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your BMR: %1 Kkal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
