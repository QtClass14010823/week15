#include "qdlg1.h"
#include <QPixmap>
#include <QSize>
#include <QIcon>
#include <QMessageBox>

Qdlg1::Qdlg1(QWidget *parent) : QDialog(parent)
{

    resize(800,400);
    gender=1;//male
    QGridLayout *gl1 = new QGridLayout(this);
    btnNext=new QPushButton(tr("Next"), this);
    btnBack=new QPushButton(tr("Back"), this);
    btnMan=new QPushButton("", this);
    btnWomen=new QPushButton("", this);
//    QLabel *lbl1 = new QLabel(tr("Select Your Gender :"), this);

    QPixmap pixM(":pic/pic/man.jpg");
    QSize mySizeM(pixM.size().width(),pixM.size().height());
    pixM = pixM.scaled(mySizeM,Qt::KeepAspectRatio);
    btnMan->resize(pixM.width(),pixM.height());
    QIcon ButtonIcon(pixM);
    btnMan->setIcon(ButtonIcon);
    btnMan->setIconSize(pixM.rect().size());

    QPixmap pixWomen(":pic/pic/women.jpg");
    QSize mySizeW(pixWomen.size().width(),pixWomen.size().height());
    pixWomen = pixWomen.scaled(mySizeW,Qt::KeepAspectRatio);
    btnWomen->resize(pixWomen.width(),pixWomen.height());
    QIcon ButtonIconW(pixWomen);
    btnWomen->setIcon(ButtonIconW);
    btnWomen->setIconSize(pixWomen.rect().size());


//    gl1->addWidget(lbl1, 0, 0,1,2);
    gl1->addWidget(btnMan,1,0);
    gl1->addWidget(btnWomen,1,1);
    gl1->addWidget(btnNext, 2, 1);
    gl1->addWidget(btnBack, 2, 0);
    this->setLayout(gl1);

    connect(btnNext,SIGNAL(clicked()),SLOT(on_btnNext_clicked()));
    connect(btnBack,SIGNAL(clicked()),SLOT(on_btnBack_clicked()));
    connect(btnMan,SIGNAL(clicked()),SLOT(on_btnMan_clicked()));
    connect(btnWomen,SIGNAL(clicked()),SLOT(on_btnWomen_clicked()));
}

void Qdlg1::on_btnNext_clicked()
{
    this->accept();
}
void Qdlg1::on_btnBack_clicked()
{
    this->reject();
}
void Qdlg1::on_btnMan_clicked()
{
    gender=1;
}
void Qdlg1::on_btnWomen_clicked()
{
    gender=0;
}
int Qdlg1::getGender()
{
    return gender;
}
