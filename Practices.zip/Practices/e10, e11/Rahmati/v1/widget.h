#ifndef WIDGET_H
#define WIDGET_H

#include "qdlg1.h"
#include "qdlg2.h"
#include "qdlg3.h"
#include "qdlg4.h"

#include <QMainWindow>
#include <QGridLayout>
#include <QLabel>
#include <QWidget>

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Qdlg1 *dlg1;
    Qdlg2 *dlg2;
    Qdlg3 *dlg3;
    Qdlg4 *dlg4;
    QGridLayout *gl1;
    QLabel *lbl1,*lblBmi,*lblBmr;
    QPushButton *btnStart;
private slots:
    void on_btnStart_clicked();
};
#endif // MAINWINDOW_H
