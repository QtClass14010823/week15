#include "widget.h"

#include <QPixmap>
#include <QSize>
#include <QMessageBox>
#include <QtMath>


Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    resize(800,400);
    setWindowTitle(tr("BMI & BMR Calculator"));

    QFont myFont("Ubuntu", 20, QFont::Bold);

    gl1 = new QGridLayout(this);
    btnStart=new QPushButton(tr("Start"),this);

    lbl1 = new QLabel(this);
    lbl1->setFont(myFont);

    lblBmr = new QLabel(this);
    lblBmr->setFont(myFont);

    lblBmi = new QLabel(this);
    lblBmi->setFont(myFont);

    QPixmap pix(":/pic/pic/images.jpeg");
    QSize mySize(800,400);
    pix = pix.scaled(mySize,Qt::IgnoreAspectRatio);
    lbl1->resize(pix.width(),pix.height());
    lbl1->setPixmap(pix);


    gl1->addWidget(lbl1, 0,0);
    gl1->addWidget(btnStart, 1,0);
    gl1->addWidget(lblBmi, 2,0);
    gl1->addWidget(lblBmr, 3,0);

    this->setLayout(gl1);

    connect(btnStart,SIGNAL(clicked()),SLOT(on_btnStart_clicked()));

}

Widget::~Widget()
{
}

void Widget::on_btnStart_clicked()
{
    int token=1;
    int res=0;
    while(true)
    {
        if(token==1)
        {
            dlg1=new Qdlg1(this);
            res = dlg1->exec();

            if (res == QDialog::Accepted)
            {
                token=2;
            }
            else
            {
                return;
            }
        }
        if(token==2)
        {
            dlg2=new Qdlg2(this);
            res = dlg2->exec();
            if (res == QDialog::Accepted)
            {
                token=3;
            }
            else
            {
                token=1;
                continue;
            }
        }

        if(token==3)
        {
            dlg3=new Qdlg3(this);
            res = dlg3->exec();
            if (res == QDialog::Accepted)
            {
                token=4;
            }
            else
            {
                token=2;
                continue;
            }
        }

        if(token==4)
        {
            dlg4=new Qdlg4(this);
            res = dlg4->exec();
            if (res == QDialog::Accepted)
            {
                break;
            }
            else
            {
                token=3;
                continue;
            }
        }
    }
    token=1;
    float bmi=dlg3->getWeight()/ qPow(dlg2->getHeight()/100.,2);
    lblBmi->setText(tr("Your BMI: %1").arg(bmi));

    if(dlg1->getGender()==0)
    {
        float bmr=(10*dlg3->getWeight())+(6.25*dlg2->getHeight())-(5*dlg4->getAge())-161;
        lblBmr->setText(tr("Your BMR: %1 Kkal").arg(bmr));
    }
    else if(dlg1->getGender()==1)
    {
        float bmr=(10*dlg3->getWeight())+(6.25*dlg2->getHeight())-(5*dlg4->getAge())+5;
        lblBmr->setText(tr("Your BMR: %1 Kcal").arg(bmr));
    }
    else
    {

    }

    QPixmap pix(":/pic/pic/BMI-res5.jpg");
    QSize mySize(lbl1->width(),lbl1->height());
    pix = pix.scaled(mySize,Qt::IgnoreAspectRatio);
    //    lbl1->resize(pix.width(),pix.height());
    lbl1->setPixmap(pix);


}

