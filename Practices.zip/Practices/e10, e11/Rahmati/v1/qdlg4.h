#ifndef QDLG4_H
#define QDLG4_H

#include <QDialog>
#include <QLabel>
#include <QPushButton>
#include <QGridLayout>
#include <QSpinBox>

class Qdlg4 : public QDialog
{
    Q_OBJECT
public:
    explicit Qdlg4(QWidget *parent = nullptr);
    int getAge();

signals:
private slots:
    void on_btnNext_clicked();
    void on_btnBack_clicked();

private:
    QPushButton *btnNext,*btnBack;
    QPushButton *btnMan,*btnWomen;
    QSpinBox *spinBox;

    int age;

};

#endif // QDLG1_H
