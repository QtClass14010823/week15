#include "qdlg4.h"
#include <QPixmap>
#include <QSize>
#include <QIcon>
#include <QMessageBox>
#include <QFont>

Qdlg4::Qdlg4(QWidget *parent) : QDialog(parent)
{

    resize(800,400);
    age=0;//unknown
    QGridLayout *gl1 = new QGridLayout(this);
    btnNext=new QPushButton(tr("Next"), this);
    btnBack=new QPushButton(tr("Back"), this);

    spinBox=new QSpinBox(this);
    spinBox->setSuffix(" Years");
    spinBox->setRange(7,120);
    spinBox->setValue(35);
    QFont myFont("Ubuntu", 20, QFont::Bold);
    spinBox->setFont(myFont);

    QLabel *lbl1 = new QLabel(tr("Enter Your Age :"), this);
    QPixmap pix(":pic/pic/age.jpeg");
    QSize mySize(800,400);
    pix = pix.scaled(mySize,Qt::IgnoreAspectRatio);
    lbl1->resize(pix.width(),pix.height());
    lbl1->setPixmap(pix);

    gl1->addWidget(lbl1, 0, 0,1,2);
    gl1->addWidget(spinBox,1,0,1,2);

    gl1->addWidget(btnNext, 2, 1);
    gl1->addWidget(btnBack, 2, 0);
    this->setLayout(gl1);

    connect(btnNext,SIGNAL(clicked()),SLOT(on_btnNext_clicked()));
    connect(btnBack,SIGNAL(clicked()),SLOT(on_btnBack_clicked()));

}

void Qdlg4::on_btnNext_clicked()
{
    this->accept();
}
void Qdlg4::on_btnBack_clicked()
{
    this->reject();
}
int Qdlg4::getAge()
{
    age=spinBox->value();
    return age;
}
