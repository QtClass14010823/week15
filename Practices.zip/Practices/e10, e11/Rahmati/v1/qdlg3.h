#ifndef QDLG3_H
#define QDLG3_H

#include <QDialog>
#include <QLabel>
#include <QPushButton>
#include <QGridLayout>
#include <QSpinBox>

class Qdlg3 : public QDialog
{
    Q_OBJECT
public:
    explicit Qdlg3(QWidget *parent = nullptr);
    int getWeight();

signals:
private slots:
    void on_btnNext_clicked();
    void on_btnBack_clicked();

private:
    QPushButton *btnNext,*btnBack;
    QPushButton *btnMan,*btnWomen;
    QSpinBox *spinBox;

    int weight;

};

#endif // QDLG1_H
