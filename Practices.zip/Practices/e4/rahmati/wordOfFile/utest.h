#ifndef UTEST_H
#define UTEST_H

#include <QObject>

class Utest : public QObject
{
    Q_OBJECT
public:
    explicit Utest(QObject *parent = nullptr);

private slots:
    void wordCount_data();
    void wordCount();
signals:

};

#endif // UTEST_H
