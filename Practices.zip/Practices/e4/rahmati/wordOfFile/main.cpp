#include "Mainwindow.h"

#include <QApplication>
#include <utest.h>
#include <QTest>
#include <QObject>

//MainWindow *mwPtr=nullptr;
#define UNIT_TEST
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    //mwPtr=&w;
    w.show();
#ifdef UNIT_TEST
    Utest utest;
    QTest::qExec(&utest);
#endif
    return a.exec();
}
