#ifndef MAINFORM_H
#define MAINFORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>
#include <QThread>
#include "Worker.h"

class MainForm : public QWidget
{
    Q_OBJECT
public:
    explicit MainForm(QWidget *parent = nullptr);
    ~MainForm();

signals:
    void startWork(QString strSrcFile, QString strDestFile);
    void pause();
    void resume();


private slots:
    void onSrcClicked();
    void onDstClicked();
    void onCopyClicked();
    void onPercentageClicked();
    void onPausClicked();
    void onResumeClicked();

private:
    QThread *workerThread;
    Worker *worker;
    QGridLayout *bLayout;
    QLabel *lblSrc, *lblDst;
    QLineEdit *lnEditSrc, *lnEditDst;
    QPushButton *btnSrcFile, *btnDstFile;
    QPushButton *btnCopy;
    QPushButton *btnPercentage;
    QPushButton *btnPause;
    QPushButton *btnResume;
};

#endif // MAINFORM_H
