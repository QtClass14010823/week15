#include "MainForm.h"
#include "Worker.h"

#include <QFileDialog>
#include <QMessageBox>
#include <QEventLoop>

MainForm::MainForm(QWidget *parent) : QWidget(parent)
{
    workerThread = new QThread(this);
    worker = new Worker;
    worker->moveToThread(workerThread);

    bLayout = new QGridLayout(this);
    lblSrc = new QLabel("Source file:", this);
    lblDst = new QLabel("Destination file:", this);
    lnEditSrc = new QLineEdit(this);
    lnEditDst = new QLineEdit(this);
    btnSrcFile = new QPushButton("...", this);
    btnDstFile = new QPushButton("...", this);
    btnCopy = new QPushButton("Copy", this);
    btnPercentage = new QPushButton("Show Percentage", this);
    btnPause = new QPushButton("Pause", this);
    btnResume= new QPushButton("Resume", this);

//    lnEditSrc->setText("/media/user1/EXTERNAL_USB/cd_images/boot-repair2-disk-64bit.iso");
//    lnEditDst->setText("/home/user1/Desktop/t.iso");

    bLayout->addWidget(lblSrc, 0, 0);
    bLayout->addWidget(lblDst, 1, 0);
    bLayout->addWidget(lnEditSrc, 0, 1);
    bLayout->addWidget(lnEditDst, 1, 1);
    bLayout->addWidget(btnSrcFile, 0, 2);
    bLayout->addWidget(btnDstFile, 1, 2);
    bLayout->addWidget(btnCopy, 3, 0, 1, 3);
    bLayout->addWidget(btnPercentage, 4, 0, 1, 3);
    bLayout->addWidget(btnPause, 5, 0, 1, 3);
    bLayout->addWidget(btnResume, 6, 0, 1, 3);

    this->setLayout(bLayout);

    this->setWindowTitle("File copy project");
    connect(btnSrcFile, &QPushButton::clicked, this, &MainForm::onSrcClicked);
    connect(btnDstFile, &QPushButton::clicked, this, &MainForm::onDstClicked);
    connect(btnCopy, &QPushButton::clicked, this, &MainForm::onCopyClicked);
    connect(btnPercentage, &QPushButton::clicked, this, &MainForm::onPercentageClicked);
    connect(btnPause, &QPushButton::clicked, this, &MainForm::onPausClicked);
    connect(btnResume, &QPushButton::clicked, this, &MainForm::onResumeClicked);
    connect(this, &MainForm::startWork, worker, &Worker::doWork, Qt::QueuedConnection);
    //    connect(this, &MainForm::pause, worker, &Worker::pause, Qt::QueuedConnection);
    //    connect(this, &MainForm::resume, worker, &Worker::resume, Qt::QueuedConnection);
    workerThread->start();

}
MainForm::~MainForm()
{
    if(workerThread->isRunning())
    {
        workerThread->quit();
        workerThread->wait();
    }
}
void MainForm::onSrcClicked()
{
    QString file1Name = QFileDialog::getOpenFileName(this,"Select source file", "/home", tr("All Files (*.*)"));

    lnEditSrc->setText(file1Name);
}
void MainForm::onDstClicked()
{
    QString file1Name = QFileDialog::getSaveFileName(this,"Select destination file", "/home", tr("All Files (*.*)"));

    lnEditDst->setText(file1Name);
}
void MainForm::onCopyClicked()
{
    emit startWork(lnEditSrc->text(),lnEditDst->text());
}
void MainForm::onPercentageClicked()
{
    QEventLoop qel;
    while(1)
    {
        qel.processEvents();
        bool finished;
        QMetaObject::invokeMethod(worker,"isFinished",Qt::BlockingQueuedConnection,Q_RETURN_ARG(bool,finished));
        if(finished==true)  break;
        qint8 retVal;
        QMetaObject::invokeMethod(worker,"getPercentage",Qt::BlockingQueuedConnection,Q_RETURN_ARG(qint8,retVal));
        setWindowTitle("%"+QString::number(retVal));
    }
}
void MainForm::onPausClicked()
{
    QMetaObject::invokeMethod(worker,"pause",Qt::QueuedConnection);
}
void MainForm::onResumeClicked()
{
    QMetaObject::invokeMethod(worker,"resume",Qt::QueuedConnection);
}
