#include "Worker.h"
#include <QFile>
#include <QEventLoop>
#include <QDebug>
#include <QThread>


Worker::Worker(QObject *parent) : QObject(parent)
{

}
Worker::~Worker()
{
}
void Worker::doWork(QString strSrcFile,QString strDestFile)
{
    QFile in(strSrcFile);
    QFile out(strDestFile);
    char buff[1024*50];
    quint64 readLen = 0;
    quint64 totalReadLen = 0;
    QEventLoop qEventLoop;

    in.open(QIODevice::ReadOnly);
    out.open(QIODevice::WriteOnly);

    paused=false;
    resumed=false;
    finished=false;
    while(!in.atEnd())
    {
        //qEventLoop.processEvents(QEventLoop::AllEvents);
        while (paused==true) {
            //qEventLoop.processEvents(QEventLoop::AllEvents);
            if(resumed==true)
            {
                paused=false;
                resumed=false;
                break;
            }
        }
        readLen = in.read(buff, sizeof(buff));
        totalReadLen += readLen;

        if (readLen > 0)
        {
            out.write(buff, readLen);
            percentage = (float)totalReadLen / (float)in.size() * 100;
        }
    }
    out.close();
    in.close();
    finished=true;
    qDebug()<<"Finished";
}
qint8 Worker::getPercentage()
{
    return percentage;
}
void Worker::pause()
{
    paused=true;
}
void Worker::resume()
{
    resumed=true;
}
bool Worker::isFinished()
{
    return finished;
}

