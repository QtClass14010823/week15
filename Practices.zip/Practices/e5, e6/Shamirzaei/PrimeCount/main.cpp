#include <iostream>
#include <QCoreApplication>
#include <QDir>
#include <QTextStream>
#include <QtConcurrent>
#include <QFuture>
#include <QVector>

QList<int> listnumbers(int min,int max)
{
    QList<int> nlist;
    for(int i=min;i<=max;i++)
        nlist.append(i);
    return nlist;
}

QList<int> map(int n)
{
    QList<int> ilist;
    int res , rem;
    res = 1;

    for(int j=2;j<n;j++)
    {
        rem = n%j;
        if(rem == 0)
        {
            if(n==45)
                n=n;
            res = 0;
            j = n;
        }
    }
    if(res == 1)
       ilist.append(n);
    return ilist;
}


void reduce(QVector<int> &primes,const QList<int>& iList)
{
    int cnt = primes.size();
    int res =0;
    for(int i = 0; i < iList.size(); i++)
    {
        res = 1;
        for(int j = 0;j< primes.size();j++)
        {
            if(primes[j] == iList.at(i))
            {
               j= primes.size();
               res = 0;
            }
        }
        if(res == 1)
        {
            if(primes.size() < cnt+1)
                primes.resize(cnt+1);
            primes[cnt] = iList.at(i);
            cnt++;
        }
    }
}

int main(int argc, char *argv[])
{
    int min = 2, max = 100;
    QCoreApplication a(argc, argv);
    QFuture<QVector<int>> f;
    QList<int> nlist = listnumbers(min,max);
    f = QtConcurrent::mappedReduced(nlist, map, reduce);
    f.waitForFinished();
    QVector<int> primes = f.result();
    for(int i=0; i<primes.size();i++)
        qDebug() << primes.at(i)<<"\n";
    return 0;
    //return a.exec();
}
