#include "Form.h"
#include "worker.h"


Form::Form(QWidget *parent) : QWidget(parent)
{
    bLayout = new QGridLayout(this);
    lblSrc = new QLabel("Source Directory:", this);
    lblDst = new QLabel("Destination Directory:", this);
    lnEditSrc = new QLineEdit(this);
    lnEditDst = new QLineEdit(this);
    btnSrcDir = new QPushButton("...", this);
    btnDstDir = new QPushButton("...", this);
    btnBckUp = new QPushButton("Back Up", this);
    lnEditSrc->setText("/home/user/Qtprjs");
    lnEditDst->setText("/home/user/testdir");
    bLayout->addWidget(lblSrc, 0, 0);
    bLayout->addWidget(lblDst, 1, 0);
    bLayout->addWidget(lnEditSrc, 0, 1);
    bLayout->addWidget(lnEditDst, 1, 1);
    bLayout->addWidget(btnSrcDir, 0, 2);
    bLayout->addWidget(btnDstDir, 1, 2);
    bLayout->addWidget(btnBckUp, 3, 0, 1, 3);
    this->setLayout(bLayout);

    this->setWindowTitle("Qt Directory back up project");
    connect(btnSrcDir, &QPushButton::clicked, this, &Form::onSrcClicked);
    connect(btnDstDir, &QPushButton::clicked, this, &Form::onDstClicked);
    connect(btnBckUp, &QPushButton::clicked, this, &Form::onBckUpClicked);
}

void Form::onSrcClicked()
{
    QString srcdir = QFileDialog::getExistingDirectory(this,"select directory to back up","/home/user");
    lnEditSrc->setText(srcdir);
}

void Form::onDstClicked()
{
    QString dstdir = QFileDialog::getExistingDirectory(this,"select destination directory","/home/user");
    lnEditDst->setText(dstdir);
}

void Form::onBckUpClicked()
{
    BackUp(lnEditSrc->text(),lnEditDst->text());
    QMessageBox::information(this,"message","The back up is in the progress at the background");
}

void Form::BackUp(QString src,QString des)
{
    QDir dirsrc(src);
    if(!dirsrc.exists())
    {
        QMessageBox::warning(this,"error","Source directory not found");
        return;
    }

    foreach(QFileInfo item, dirsrc.entryInfoList())
    {
        if(item.isDir() && item.fileName() != (QString(".")) && item.fileName() != QString(".."))
        {
            QDir dir(des+item.absoluteFilePath());

            if(!dir.exists())
            {
                qDebug()<<"Creating Dir:"<<item.absoluteFilePath()<<"\n";
                dir.mkpath(des+item.absoluteFilePath());
            }
           BackUp(item.absoluteFilePath(),des);
        }
        if(item.isFile())
        {
            QDir dir(item.absolutePath());
            qDebug()<<"copy file:"<<item.absoluteFilePath()<<"\n";

            if(!dir.exists())
                dir.mkpath(des+item.absolutePath());
             QThread *workerThread = new QThread(this);
             Worker *worker = new Worker();
             worker->src = item.absoluteFilePath();;
             worker->dst =des+item.absoluteFilePath();
             worker->moveToThread(workerThread);
             connect(workerThread, &QThread::finished, worker, &QObject::deleteLater, Qt::AutoConnection);
             workerThread->start();
             QMetaObject::invokeMethod(worker, "doWork", Qt::AutoConnection);
        }
    }


}

