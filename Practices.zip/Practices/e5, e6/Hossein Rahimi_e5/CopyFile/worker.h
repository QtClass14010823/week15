#ifndef WORKER_H
#define WORKER_H

#include <QObject>

class Worker : public QObject
{
    Q_OBJECT
public:
    explicit Worker(QObject *parent = nullptr);
    bool copy_pause;

public slots:
    void doWork(const QString src_str,const QString dst_str);
    void doPuse(const bool cp_pause);

signals:
  //  void onWorkeReturn(bool res );
private:

};

#endif // WORKER_H
