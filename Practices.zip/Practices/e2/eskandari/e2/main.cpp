#include <QApplication>
#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QWidget myWidget;
    QLabel **myLabels = new QLabel*[argc-1];
    QLineEdit **myLedits = new QLineEdit*[argc-1];
    QLabel paramcL("Parameters Count :", &myWidget);
    paramcL.move(10, 10);
    QLabel paramvL(QString::number(argc-1), &myWidget);
    paramvL.move(150, 10);

    QString labelBaseStr="Parameter ";
    QString labelStr, labelAddedStr;

    for(int i=0; i < argc-1; i++)
    {
        labelAddedStr = QString::number(i+1);
        labelStr = labelBaseStr + labelAddedStr + " :";
        myLabels[i] = new QLabel;
        myLabels[i]->setText(labelStr);
        myLabels[i]->setParent(&myWidget);
        myLabels[i]->move(10, 40+i*30);

        myLedits[i] = new QLineEdit;
        myLedits[i]->setText(argv[i+1]);
        myLedits[i]->setParent(&myWidget);
        myLedits[i]->move(110, 40+i*30);
        myLedits[i]->setReadOnly(true);
    }

    QPushButton exitPB("Exit", &myWidget);
    exitPB.move(170, 50+(argc-1)*30);

    myWidget.show();

    QObject::connect(&exitPB, &QPushButton::clicked, &app, &QApplication::quit);

    int retVal = app.exec();
    delete[] myLabels;
    delete[] myLedits;
    return retVal;
}
