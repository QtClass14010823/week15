#include <QCoreApplication>
#include<QVector>

#include<iostream>

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    QVector<int> vec = {1, 2, 3, 4, 5};

    cout<<"The size of the vector is: " << vec.size() << endl;

    cout<<"The first item is: " << vec.first() << endl;
    cout<<"The last item is: " << vec.last() << endl;

    vec.append(6);  // adding new element at the end
    vec.prepend(0); // adding new element at the beginning

    cout<<"Elements are: ";

    for (int val : vec) { //for each loop
       cout << val << " ";
    }

    return 0;
}
