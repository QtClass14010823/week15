#include <QApplication>
#include <QWidget>
#include <QThreadPool>
#include <QRunnable>
#include <QHBoxLayout>
#include <QPushButton>
#include <QDebug>

class MyTask : public QRunnable
{
    void run() override
    {
        /* ... here is the expensive or blocking operation ... */
        for (int i = 0; i < 10; i++)
        {
            qDebug() << i;

            QThread::sleep(1);
        }
    }
};

class Form : public QWidget
{
    Q_OBJECT

public:
    Form(QWidget *parent = nullptr);
    ~Form();

signals:

private slots:
    void onBtn1Clicked();
    void onBtn2Clicked();

private:
    MyTask *task;
    QHBoxLayout *layout;
    QPushButton *btn1, *btn2;
};

Form::Form(QWidget *parent) : QWidget(parent)
{
    layout = new QHBoxLayout(this);
    btn1 = new QPushButton("Counting numbers");
    btn2 = new QPushButton("Terminate");

    layout->addWidget(btn1);
    layout->addWidget(btn2);

    connect(btn1, &QPushButton::clicked, this, &Form::onBtn1Clicked);
    connect(btn2, &QPushButton::clicked, this, &Form::onBtn2Clicked);
}

Form::~Form()
{
}

void Form::onBtn1Clicked()
{
    task = new MyTask;
    // QThreadPool takes ownership and deletes 'hello' automatically
    QThreadPool::globalInstance()->start(task);
}

void Form::onBtn2Clicked()
{
    QThreadPool::globalInstance()->waitForDone();
}

#include "main.moc"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Form frm;

    frm.show();
    return a.exec();
}
