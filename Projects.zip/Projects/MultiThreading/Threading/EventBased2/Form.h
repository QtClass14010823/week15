#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QThread>
#include <QHBoxLayout>
#include <QPushButton>

#include "Worker.h"

class Form : public QWidget
{
    Q_OBJECT

public:
    Form(QWidget *parent = nullptr);
    ~Form();

signals:

private slots:
    void onBtn1Clicked();
    void onBtn2Clicked();
    void onBtn3Clicked();
    void onThreadFinished();

private:
    QThread *workerThread;
    QHBoxLayout *layout;
    QPushButton *btn1, *btn2, *btn3;
    Worker *worker;
};

#endif // FORM_H
