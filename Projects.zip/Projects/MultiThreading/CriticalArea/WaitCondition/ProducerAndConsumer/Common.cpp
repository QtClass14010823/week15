#include "Common.h"

const int DataSize = 100000;

const int BufferSize = 8192;
char buffer[BufferSize];
int numUsedBytes;

QMutex mutex; // protects the buffer and the counter
QWaitCondition bufferNotEmpty;
QWaitCondition bufferNotFull;
