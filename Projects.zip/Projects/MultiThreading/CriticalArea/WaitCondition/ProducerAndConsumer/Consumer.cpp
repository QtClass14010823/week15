#include "Consumer.h"

#include <QDebug>

#include "Common.h"

Consumer::Consumer(QObject *parent) :
    QThread(parent)
{
}

void Consumer::run()
{
    for (int i = 0; i < DataSize; ++i) 
	{
		{
			const QMutexLocker locker(&mutex);

			while (numUsedBytes == 0)
				bufferNotEmpty.wait(&mutex);
		}
		
        qDebug() << buffer[i % BufferSize];
		
		{
			const QMutexLocker locker(&mutex);
			--numUsedBytes;
			bufferNotFull.wakeAll();
		}

        emit bufferFillCountChanged(numUsedBytes);
        emit consumerCountChanged(i);
    }
}
