#include "Form.h"

#include <QDebug>
#include <QtConcurrent>

QStringList StartGlobalWork(QString str)
{
    QThread::sleep(10);
    return str.split(',', Qt::SkipEmptyParts);
}

Form::Form(QWidget *parent) : QWidget(parent)
{
    layout = new QGridLayout(this);
    btnStartWork = new QPushButton("Start Work");
    btnStartGlobalWork = new QPushButton("Start Global Work");
    btnStartAsyncGlobalWork = new QPushButton("Start Async Global Work");
    btnRunLambdaFunction = new QPushButton("Run Lambda Function");

    layout->addWidget(btnStartWork);
    layout->addWidget(btnStartGlobalWork);
    layout->addWidget(btnStartAsyncGlobalWork);
    layout->addWidget(btnRunLambdaFunction);

    connect(btnStartWork, &QPushButton::clicked, this, &Form::onBtnStartWorkClicked);
    connect(btnStartGlobalWork, &QPushButton::clicked, this, &Form::onBtnStartGlobalWorkClicked);
    connect(btnStartAsyncGlobalWork, &QPushButton::clicked, this, &Form::onBtnStartAsyncGlobalWorkClicked);
    connect(btnRunLambdaFunction, &QPushButton::clicked, this, &Form::onBtnRunLambdaFunction);
    connect(&watcher, &QFutureWatcher<QStringList>::finished, this, &Form::onAsyncGlobalWorkFinished);
}

Form::~Form()
{
}

void Form::onBtnStartWorkClicked()
{
    QFuture<void> future = QtConcurrent::run(this, &Form::startWork, true);
}

void Form::onBtnStartGlobalWorkClicked()
{
    QFuture<QStringList> future = QtConcurrent::run(&StartGlobalWork, QString("Ali,Reza,Sajad,Ahmad,Mohsen"));
    QStringList result = future.result();

    foreach(QString str, result)
        qDebug() << str;
}

void Form::onBtnStartAsyncGlobalWorkClicked()
{
    QFuture<QStringList> future = QtConcurrent::run(&StartGlobalWork, QString("Ali,Reza,Sajad,Ahmad,Mohsen"));
    watcher.setFuture(future);
}

void Form::onAsyncGlobalWorkFinished()
{
    QStringList result = watcher.result();

    foreach(QString str, result)
        qDebug() << str;
}

void Form::onBtnRunLambdaFunction()
{
    QtConcurrent::run([=]() {
        // Code in this block will run in another thread
        for (int i = 0; i < 10; i++)
        {
            if (i % 2 == 1)
                qDebug() << i;

            QThread::sleep(1);
        }
    });
}


void Form::startWork(const bool isEven)
{
    /* ... here is the expensive or blocking operation ... */
    for (int i = 0; i < 10; i++)
    {
        if (i % 2 == (isEven) ? 0 : 1)
            qDebug() << i;

        QThread::sleep(1);
    }
}
