#include <iostream>

#include <QCoreApplication>
#include <QDir>
#include <QTextStream>
#include <QtConcurrent>
#include <QFuture>
#include <QVector>

const int yearInterval = 5;

QStringList findFiles(const QString &dirPath, const QString &fileStart)
{
    QStringList filePaths;
    QDir dir(dirPath);

    foreach (QString file, dir.entryList(QDir::Files)){
        if(file.startsWith(fileStart))
            filePaths += dirPath + "/" + file;
    }

    return filePaths;
}

QList<int> mapFile(const QString& fileName) {
    QFile file(fileName);
    file.open(QIODevice::ReadOnly);
    QTextStream in(&file);

    QList<int> ageList;
    while (!in.atEnd()) {
        QString line = in.readLine();
        line = line.trimmed();
        if(!line.isEmpty()){
            bool iOk = false;
            int i = line.toInt(&iOk);
            if(iOk)
                ageList.append(i);
        }
    }
    return ageList;
}

void reduce(QVector<int> &product,
                              const QList<int> &ageList) {
    for(int i = 0; i < ageList.size(); i++){
        int binNr = ageList.at(i) / yearInterval;
        if(product.size() < binNr+1)
            product.resize(binNr+1);
        product[binNr]++;
    }
}

void drawCharacterHistogram(const QVector<int> &ageIntervals){
    for(int i = 0; i < ageIntervals.size(); i++)
    {
        if (ageIntervals[i] > 0)
        {
            std::cout << i * yearInterval << '-' << (i + 1) * yearInterval << ":\t";

            for (int j = 0; j < ageIntervals[i]; j++)
                std::cout << "#";

                std::cout << std::endl;
            }
    }
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QStringList filePaths = findFiles(QDir::currentPath(), "city");
    QFuture<QVector<int>> f1;
    f1 = QtConcurrent::mappedReduced(filePaths, mapFile, reduce);
    f1.waitForFinished();
    QVector<int> finalDistrib = f1.result();
    qDebug() << finalDistrib;
    drawCharacterHistogram(finalDistrib);

    return 0;
    //return a.exec();
}
