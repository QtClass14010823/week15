#include <QApplication>
#include <QLabel>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QLabel label("Salam.");
    label.show();

    return a.exec();
}
-------------------------------
#include <QApplication>
#include <QLabel>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QLabel *label = new QLabel("Salam.");
    label->show();

    int ret = a.exec();

    delete label;

    return ret;
}
-------------------------------
#include <QApplication>
#include <QLabel>
#include <QWidget>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QWidget widget;
    QLabel label("Salam.", &widget);
    
    widget.show();

    return a.exec();
}
-------------------------------
#include <QApplication>
#include <QLabel>
#include <QWidget>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QWidget widget;
    QLabel label1("Ali", &widget);
    QLabel label2("Ahmad", &widget);
    QLabel label3("Mohsen", &widget);

    label1.move(0, 0);
    label2.move(0, 10);
    label3.move(0, 20);
    widget.show();

    return a.exec();
}
-------------------------------
// Buggy
#include <QApplication>
#include <QLabel>
#include <QWidget>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QWidget widget;
    QLabel *labelArr = nullptr;

    labelArr = new QLabel[argc];

    if (!labelArr)
    {
        return 1;
    }

    for (int i = 0; i < argc; i++)
    {
        labelArr[i].setParent(&widget);
        labelArr[i].setText(argv[i]);
        labelArr[i].move(0, i * 10);
    }

    widget.show();

    return a.exec();
}
-------------------------------
#include <QApplication>
#include <QLabel>
#include <QWidget>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QWidget widget;

    for (int i = 0; i < argc; i++)
    {
        QLabel *label = new QLabel;
        label->setParent(&widget);
        label->setText(argv[i]);
        label->move(0, i * 10);
    }

    widget.show();

    return a.exec();
}
-------------------------------
#include <QApplication>
#include <QLabel>
#include <QWidget>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QWidget widget;
    QLabel **labelArr = new QLabel*[argc];

    for (int i = 0; i < argc; i++)
    {
        labelArr[i] = new QLabel;
        labelArr[i]->setParent(&widget);
        labelArr[i]->setText(argv[i]);
        labelArr[i]->move(0, i * 10);
    }

    widget.show();

    int ret = a.exec();

    delete[] labelArr;

    return ret;
}

