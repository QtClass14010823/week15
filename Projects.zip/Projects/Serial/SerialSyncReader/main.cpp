#include <QCoreApplication>
#include <QSerialPort>

#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QSerialPort serial;

    serial.setPortName("COM4");
    serial.setBaudRate(QSerialPort::Baud9600);
    serial.setDataBits(QSerialPort::Data8);
    serial.setParity(QSerialPort::NoParity);
    serial.setStopBits(QSerialPort::OneStop);
    serial.setFlowControl(QSerialPort::NoFlowControl);

    if (!serial.open(QIODevice::ReadOnly))
    {
        cout << "Failed to open port." << endl;
        cout << "Error: " << serial.errorString().toStdString().c_str() << endl;
        return 1;
    }

    QByteArray readData = serial.readAll();

    if (readData.size())
        cout << "Data successfully recived: " << readData.toHex().toStdString().c_str() << endl;

    while(serial.waitForReadyRead(10000))
    {
        readData = serial.readAll();

        cout << "Data successfully recived: " << readData.toHex().toStdString().c_str() << endl;
    }

    if (serial.error() == QSerialPort::ReadError)
    {
        cout << "An I/O error occured while reading the data." << endl;
        cout << "Error: " << serial.errorString().toStdString().c_str() << endl;
        return 1;
    }
    else if (serial.error() == QSerialPort::TimeoutError)
    {
        cout << "A timeout occurred." << endl;
        return 1;
    }

    return 0;
}
