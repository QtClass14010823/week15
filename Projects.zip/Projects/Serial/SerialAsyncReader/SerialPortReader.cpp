#include "SerialPortReader.h"

#include <iostream>

#include <QCoreApplication>

using namespace std;

SerialPortReader::SerialPortReader(QObject *parent) : QObject(parent)
{
    m_serial.setPortName("COM4");
    m_serial.setBaudRate(QSerialPort::Baud9600);
    m_serial.setDataBits(QSerialPort::Data8);
    m_serial.setParity(QSerialPort::NoParity);
    m_serial.setStopBits(QSerialPort::OneStop);
    m_serial.setFlowControl(QSerialPort::NoFlowControl);

    if (!m_serial.open(QIODevice::ReadOnly))
    {
        cout << "Failed to open port." << endl;
        cout << "Error: " << m_serial.errorString().toStdString().c_str() << endl;
    }

    connect(&m_serial, &QSerialPort::readyRead, this, &SerialPortReader::handleReadyRead);
    connect(&m_serial, &QSerialPort::errorOccurred, this, &SerialPortReader::handleError);
}

SerialPortReader::~SerialPortReader()
{
    if (m_serial.isOpen())
    {
        m_serial.close();
    }
}

void SerialPortReader::handleReadyRead()
{
    QByteArray buff;

    buff = m_serial.readAll();
    cout << "Data successfully recived: " << buff.toHex().toStdString().c_str() << endl;

    foreach (unsigned char c, buff) {
        if (c == '\0')
            QCoreApplication::exit(0);
    }

//    while (!m_serial.atEnd())
//    {
//        char ch;

//        m_serial.read(&ch, 1);
//        cout << "Data successfully recived: " << QByteArray(&ch, 1).toHex().toStdString().c_str() << endl;

//        if (ch == '\0')
//            QCoreApplication::exit(0);
//    }
}

void SerialPortReader::handleError(QSerialPort::SerialPortError serialPortError)
{
    if (serialPortError == QSerialPort::ReadError)
    {
        cout << "An I/O error occured while reading the data." << endl;
        cout << "Error: " << m_serial.errorString().toStdString().c_str() << endl;
    }
    else
    {
        cout << "Error: " << m_serial.errorString().toStdString().c_str() << endl;
    }
}
