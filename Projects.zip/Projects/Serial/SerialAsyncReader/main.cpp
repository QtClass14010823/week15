#include <QCoreApplication>

#include "SerialPortReader.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    SerialPortReader serialPort;

    return a.exec();
}
