#include "WorkerThread.h"

#include <iostream>

#include <QCoreApplication>

using namespace std;

WorkerThread::WorkerThread(QObject *parent) : QThread(parent)
{
}

WorkerThread::~WorkerThread()
{
    m_mutex.lock();
    m_quit = true;
    m_mutex.unlock();
    wait();
}

void WorkerThread::startReceiver(const QString &portName, int waitTimeout, const QString &response)
{
    const QMutexLocker locker(&m_mutex);

    m_portName = portName;
    m_waitTimeout = waitTimeout;
    m_response = response;

    if (!isRunning())
        start();
}

void WorkerThread::run()
{
    bool currentPortNameChanged = false;

    m_mutex.lock();
    QString currentPortName;

    if (currentPortName != m_portName)
    {
        currentPortName = m_portName;
        currentPortNameChanged = true;
    }

    int currentWaitTimeout = m_waitTimeout;
    QString currentRespone = m_response;;
    m_mutex.unlock();

    QSerialPort serial;

    if (currentPortName.isEmpty())
    {
        emit error(tr("No port name specified"));
        return;
    }

    while (!m_quit)
    {
        if (currentPortNameChanged)
        {
            serial.close();
            serial.setPortName(currentPortName);

            if (!serial.open(QIODevice::ReadWrite))
            {
                emit error(tr("Can't open %1, error code %2")
                           .arg(m_portName).arg(serial.error()));
                return;
            }
        }

        if (serial.waitForReadyRead(currentWaitTimeout))
        {
            // read request
            QByteArray requestData = serial.readAll();

            while (serial.waitForReadyRead(10))
                requestData += serial.readAll();

            // write response
            const QByteArray responseData = currentRespone.toUtf8();

            serial.write(responseData);

            if (serial.waitForBytesWritten(m_waitTimeout))
            {
                const QString request = QString::fromUtf8(requestData);
                emit this->request(request);
            }
            else
            {
                emit timeout(tr("Wait write response timeout."));
            }
        }
        else
        {
            emit timeout(tr("Wait read request timeout."));
        }

        m_mutex.lock();

        if (currentPortName != m_portName)
        {
            currentPortName = m_portName;
            currentPortNameChanged = true;
        }
        else
        {
            currentPortNameChanged = false;
        }

        currentWaitTimeout = m_waitTimeout;
        currentRespone = m_response;
        m_mutex.unlock();
    }
}
