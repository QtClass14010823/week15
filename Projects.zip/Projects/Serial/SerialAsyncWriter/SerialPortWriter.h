#ifndef SERIALPORTWRITER_H
#define SERIALPORTWRITER_H

#include <QObject>
#include <QSerialPort>

class SerialPortWriter : public QObject
{
    Q_OBJECT
public:
    explicit SerialPortWriter(QObject *parent = 0);
    ~SerialPortWriter();
    void write(const QByteArray &data);

signals:

public slots:

private slots:
    void handleBytesWritten(quint64 bytes);
    void handleError(QSerialPort::SerialPortError serialPortError);

private:
    QSerialPort m_serial;
    quint64 m_byteWritten;
    QByteArray m_writeData;
};

#endif // SERIALPORTWRITER_H
