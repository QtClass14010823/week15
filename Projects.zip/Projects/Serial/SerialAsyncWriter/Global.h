#ifndef GLOBAL_H
#define GLOBAL_H

int char2int(char input);

// This function assumes src to be a zero terminated sanitized string with
// an even number of [0-9a-f] characters, and target to be sufficiently large
void hex2bin(const char* src, char* target);

#endif // GLOBAL_H
