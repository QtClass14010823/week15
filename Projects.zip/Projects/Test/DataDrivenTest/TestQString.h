#ifndef TEST_H
#define TEST_H

#include <QObject>
#include <QTest>

class TestQString: public QObject
{
    Q_OBJECT

private slots:
    void toUpper_data();
    void toUpper();
};

#endif // TEST_H
