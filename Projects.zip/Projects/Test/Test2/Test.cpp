#include "Test.h"

void TestFooClass::test_func_foo() {}

void TestBarClass::test_func_bar() {}
