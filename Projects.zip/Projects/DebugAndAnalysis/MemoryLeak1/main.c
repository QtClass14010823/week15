#include <time.h>
#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int ARR_SIZE = 1000;

    // Create an array of ARR_SIZE ints
    int *intArray = (int *)malloc(sizeof(int) * ARR_SIZE);

    // Populate them
    for (int i = 0; i < ARR_SIZE; i++)
    {
        intArray[i] = i;
    }

    // Print one out
    // First, seed the random number generator
    srand(time(NULL));
    int randNum = rand() % ARR_SIZE;

    printf("intArray[%d]: %d\n", randNum, intArray[randNum]);

    //free(intArray);
    // End without freeing!
    return 0;
}
