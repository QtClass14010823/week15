#ifndef SUBWINDOW_H
#define SUBWINDOW_H

#include <QLabel>

class SubWindow : public QLabel
{
    Q_OBJECT
public:
    SubWindow(QWidget *parent = nullptr);
};

#endif // SUBWINDOW_H
