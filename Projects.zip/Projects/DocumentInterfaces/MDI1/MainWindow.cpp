#include "MainWindow.h"

#include <QPushButton>
#include <QVBoxLayout>

#include "SubWindow.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{
    QWidget *w = new QWidget(this);
    QPushButton *p = new QPushButton("New Sub-window", this);

    mdi = new QMdiArea(this);

    QVBoxLayout *l = new QVBoxLayout(w);

    l->addWidget(p);
    l->addWidget(mdi);
    w->setLayout(l);
    setCentralWidget(w);

    connect(p, SIGNAL(clicked()), this, SLOT(addSubWin()));
}

void MainWindow::addSubWin()
{
    SubWindow *sw = new SubWindow;

    mdi->addSubWindow(sw);
    sw->show();
}
