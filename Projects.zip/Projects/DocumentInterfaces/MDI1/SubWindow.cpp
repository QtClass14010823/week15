#include "SubWindow.h"

SubWindow::SubWindow(QWidget *parent) : QLabel(parent)
{
    setText("I'm a sub-window");
}
