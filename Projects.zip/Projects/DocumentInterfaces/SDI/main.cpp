#include <QApplication>

#include "MainWindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // It does not need to be removed due to the use of
    // setAttribute(Qt::WA_DeleteOnClose) in MainWindow
    MainWindow *mainWin = nullptr;

    mainWin = new MainWindow;
    mainWin->show();

    return a.exec();
}
