#include "MainWindow.h"

#include <QCoreApplication>
#include <QMenuBar>
#include <QToolBar>
#include <QStatusBar>
#include <QTextEdit>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{
    init();
}

MainWindow::~MainWindow()
{
}

void MainWindow::newFile()
{
    textEdit->clear();
}

void MainWindow::open()
{
    const QString fileName = QFileDialog::getOpenFileName(this);

    if (fileName.isEmpty())
        return;

    QFile file(fileName);

    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox::warning(this, tr("SDI"),
                             tr("Cannot read file %1:\n%2.")
                             .arg(fileName, file.errorString()));
        return;
    }

    QTextStream in(&file);
    textEdit->setPlainText(in.readAll());
    file.close();
    statusBar()->showMessage(tr("File loaded"), 2000);
}

void MainWindow::save()
{
    QString fileName = QFileDialog::getSaveFileName(this, tr("Save As"));

    if (fileName.isEmpty())
        return;

    QFile file(fileName);

    if (file.open(QFile::WriteOnly | QFile::Text))
    {
        QTextStream out(&file);

        out << textEdit->toPlainText();
    }
    else
    {
        QMessageBox::critical(this, tr("SDI"),
                             tr("Cannot open file %1 for writing:\n%2.")
                             .arg(fileName, file.errorString()));
    }

    file.close();
    statusBar()->showMessage(tr("File saved"), 2000);
}

void MainWindow::init()
{
    setAttribute(Qt::WA_DeleteOnClose);

    QMenu *fileMenu = menuBar()->addMenu("&File");
    QToolBar *fileToolBar = addToolBar("File");

    QAction *newAct = new QAction(tr("&New"), this);
    newAct->setShortcuts(QKeySequence::New);
    newAct->setStatusTip(tr("Create a new file"));
    connect(newAct, &QAction::triggered, this, &MainWindow::newFile);
    fileMenu->addAction(newAct);
    fileToolBar->addAction(newAct);

    QAction *openAct = new QAction(tr("&Open..."), this);
    openAct->setShortcuts(QKeySequence::Open);
    openAct->setStatusTip(tr("Open an existing file"));
    connect(openAct, &QAction::triggered, this, &MainWindow::open);
    fileMenu->addAction(openAct);
    fileToolBar->addAction(openAct);

    QAction *saveAct = new QAction(tr("&Save"), this);
    saveAct->setShortcuts(QKeySequence::Save);
    saveAct->setStatusTip(tr("Save the document to disk"));
    connect(saveAct, &QAction::triggered, this, &MainWindow::save);
    fileMenu->addAction(saveAct);
    fileToolBar->addAction(saveAct);

    fileMenu->addSeparator();

    QAction *closeAct = fileMenu->addAction(tr("&Close"), this, &QCoreApplication::quit);
    closeAct->setShortcut(tr("Ctrl+W"));
    closeAct->setStatusTip(tr("Close this window"));

    textEdit = new QTextEdit;
    setCentralWidget(textEdit);
    statusBar()->showMessage(tr("Ready"));
}
