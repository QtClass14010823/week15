#include "MdiChild.h"

#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>

MdiChild::MdiChild()
{
    setAttribute(Qt::WA_DeleteOnClose);
}

void MdiChild::newFile()
{
    clear();
}

bool MdiChild::open()
{
    const QString fileName = QFileDialog::getOpenFileName(this);

    if (fileName.isEmpty())
        return false;

    QFile file(fileName);

    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox::warning(this, tr("SDI"),
                             tr("Cannot read file %1:\n%2.")
                             .arg(fileName, file.errorString()));
        return false;
    }

    QTextStream in(&file);
    setPlainText(in.readAll());
    file.close();

    return true;
}

bool MdiChild::save()
{
    QString fileName = QFileDialog::getSaveFileName(this, tr("Save As"));

    if (fileName.isEmpty())
        return false;

    QFile file(fileName);

    if (file.open(QFile::WriteOnly | QFile::Text))
    {
        QTextStream out(&file);

        out << toPlainText();
    }
    else
    {
        QMessageBox::critical(this, tr("SDI"),
                             tr("Cannot open file %1 for writing:\n%2.")
                             .arg(fileName, file.errorString()));
        return false;
    }

    file.close();
    return true;
}
