#ifndef MDICHILD_H
#define MDICHILD_H

#include <QTextEdit>

class MdiChild : public QTextEdit
{
    Q_OBJECT

public:
    MdiChild();
    void newFile();
    bool open();
    bool save();
};

#endif // MDICHILD_H
