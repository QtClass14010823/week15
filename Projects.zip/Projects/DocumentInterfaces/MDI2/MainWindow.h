#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMdiArea>
#include <QAction>

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);

private slots:
    void newFile();
    void open();
    void save();
    void updateMenus();

private:
    QMdiArea *mdiArea;
    QAction *newAct;
    QAction *openAct;
    QAction *saveAct;

    void init();
};

#endif // MAINWINDOW_H
