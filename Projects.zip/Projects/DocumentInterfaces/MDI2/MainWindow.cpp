#include "MainWindow.h"

#include <QCoreApplication>
#include <QMdiSubWindow>
#include <QMenuBar>
#include <QToolBar>
#include <QStatusBar>

#include "MdiChild.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent),
    mdiArea(new QMdiArea)
{
    mdiArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    mdiArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    setCentralWidget(mdiArea);
    init();

    connect(mdiArea, &QMdiArea::subWindowActivated,
            this, &MainWindow::updateMenus);
}

void MainWindow::newFile()
{
    MdiChild *child = new MdiChild;

    mdiArea->addSubWindow(child);
    child->show();
}

void MainWindow::open()
{
    if (mdiArea->activeSubWindow())
    {
        MdiChild *child = dynamic_cast<MdiChild *>(mdiArea->activeSubWindow()->widget());

        if (child && child->open())
            statusBar()->showMessage(tr("File loaded"), 2000);
    }
}

void MainWindow::save()
{
    if (mdiArea->activeSubWindow())
    {
        MdiChild *child = dynamic_cast<MdiChild *>(mdiArea->activeSubWindow()->widget());

        if (child && child->save())
            statusBar()->showMessage(tr("File saved"), 2000);
    }
}

void MainWindow::updateMenus()
{
    bool hasMdiChild = false;

    if (QMdiSubWindow *activeSubWindow = mdiArea->activeSubWindow())
    {
        hasMdiChild = (qobject_cast<MdiChild *>(activeSubWindow->widget()) != nullptr);
    }

    openAct->setEnabled(hasMdiChild);
    saveAct->setEnabled(hasMdiChild);
}

void MainWindow::init()
{
    QMenu *fileMenu = menuBar()->addMenu("&File");
    QToolBar *fileToolBar = addToolBar("File");

    newAct = new QAction(tr("&New"), this);
    newAct->setShortcuts(QKeySequence::New);
    newAct->setStatusTip(tr("Create a new file"));
    connect(newAct, &QAction::triggered, this, &MainWindow::newFile);
    fileMenu->addAction(newAct);
    fileToolBar->addAction(newAct);

    openAct = new QAction(tr("&Open..."), this);
    openAct->setShortcuts(QKeySequence::Open);
    openAct->setStatusTip(tr("Open an existing file"));
    connect(openAct, &QAction::triggered, this, &MainWindow::open);
    fileMenu->addAction(openAct);
    fileToolBar->addAction(openAct);

    saveAct = new QAction(tr("&Save"), this);
    saveAct->setShortcuts(QKeySequence::Save);
    saveAct->setStatusTip(tr("Save the document to disk"));
    connect(saveAct, &QAction::triggered, this, &MainWindow::save);
    fileMenu->addAction(saveAct);
    fileToolBar->addAction(saveAct);

    fileMenu->addSeparator();

    QAction *closeAct = fileMenu->addAction(tr("&Close"), this, &QCoreApplication::quit);
    closeAct->setShortcut(tr("Ctrl+W"));
    closeAct->setStatusTip(tr("Close this window"));

    statusBar()->showMessage(tr("Ready"));
    updateMenus();
}
