#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>

class Form : public QWidget
{
    Q_OBJECT

public:
    Form(QWidget *parent = Q_NULLPTR, Qt::WindowFlags f = Qt::WindowFlags());

private slots:
    void on_BtnOk_Clicked();

private:
    QGridLayout *layout;
    QLabel *lblTitle;
    QLineEdit *editName;
    QPushButton *btnOk;

    void retranslateUi();
};

#endif // FORM_H
