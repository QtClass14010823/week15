<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>Form</name>
    <message>
        <location filename="Form.cpp" line="34"/>
        <source>Title:</source>
        <translation>عنوان:</translation>
    </message>
    <message>
        <location filename="Form.cpp" line="35"/>
        <source>OK</source>
        <translation>تایید</translation>
    </message>
    <message>
        <location filename="Form.cpp" line="33"/>
        <source>Form</source>
        <translation>فرم</translation>
    </message>
    <message>
        <location filename="Form.cpp" line="28"/>
        <source>Information</source>
        <translation>اطلاعات</translation>
    </message>
</context>
</TS>
