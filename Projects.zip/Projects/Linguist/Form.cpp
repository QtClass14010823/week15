#include "Form.h"

#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>
#include <QCoreApplication>

Form::Form(QWidget *parent/* = Q_NULLPTR*/, Qt::WindowFlags f/* = Qt::WindowFlags()*/) :
    QWidget(parent, f)
{
    this->setObjectName(QString::fromUtf8("Form"));
    layout = new QGridLayout(this);
    lblTitle = new QLabel(this);
    editName = new QLineEdit(this);
    btnOk = new QPushButton(this);

    layout->addWidget(lblTitle, 0, 0);
    layout->addWidget(editName, 0, 1);
    layout->addWidget(btnOk, 0, 2);

    this->setLayout(layout);

    retranslateUi();

    connect(btnOk, &QPushButton::clicked, this, &Form::on_BtnOk_Clicked);
}

void Form::on_BtnOk_Clicked()
{
    QMessageBox::information(this, tr("Information"), QString("Hello!"));
}

void Form::retranslateUi()
{
    this->setWindowTitle(QCoreApplication::translate("Form", "Form", nullptr));
    lblTitle->setText(QCoreApplication::translate("Form", "Title:", nullptr));
    btnOk->setText(QCoreApplication::translate("Form", "OK", nullptr));
}
